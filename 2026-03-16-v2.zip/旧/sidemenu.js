// Dark mode init (runs before DOM builds - prevents flash)
(function(){var s=localStorage.getItem('darkMode');if(s==='1')document.documentElement.setAttribute('data-theme','dark');else if(s==='0')document.documentElement.setAttribute('data-theme','light');})();

window.applyDarkMode=function(d){if(d){document.documentElement.setAttribute('data-theme','dark');localStorage.setItem('darkMode','1');}else{document.documentElement.setAttribute('data-theme','light');localStorage.setItem('darkMode','0');}var c=document.getElementById('darkModeToggle');if(c)c.checked=d;};

window.QUICK_ITEMS=[
  {text:'🟥HELP🟥',label:'🟥HELP🟥'},{text:'🟨保留中🟨',label:'🟨保留中🟨'},
  {text:'🟦後処理🟦',label:'🟦後処理🟦'},{text:'📱【検証機使用希望】📱（iPhone）',label:'iPhone'},
  {text:'📱【検証機使用希望】📱（Android）',label:'Android'},{text:'☕10分休憩よろしいでしょうか☕',label:'10分休憩'},
  {text:'🍱お昼休憩よろしいでしょうか🍱',label:'お昼休憩'},{text:'🐻離席してもよろしいでしょうか🐻',label:'お手洗い'},
];

window.renderQuickMenu=function(){var el=document.getElementById('quickMenu');if(!el)return;el.innerHTML=window.QUICK_ITEMS.map(function(item,i){return'<div class="quick-menu-item" data-qi="'+i+'">'+item.label+'</div>';}).join('');el.addEventListener('click',function(ev){var d=ev.target.closest('[data-qi]');if(!d)return;var item=window.QUICK_ITEMS[parseInt(d.dataset.qi)];if(item)window.copyText(item.text,item.label);});};
window.toggleQuickMenu=function(){var menu=document.getElementById('quickMenu');if(menu)menu.classList.toggle('open');};
window.copyText=function(text,label){function doToast(){var menu=document.getElementById('quickMenu');if(menu)menu.classList.remove('open');var toast=document.getElementById('quickCopyToast');if(!toast)return;toast.textContent='「'+label+'」をコピーしました';toast.classList.add('show');setTimeout(function(){toast.classList.remove('show');},2000);}if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(text).then(doToast).catch(function(){_fallbackCopy(text);doToast();});}else{_fallbackCopy(text);doToast();}};
function _fallbackCopy(text){var el=document.createElement('textarea');el.value=text;document.body.appendChild(el);el.select();document.execCommand('copy');document.body.removeChild(el);}

window.triggerImport=function(){var el=document.getElementById('importFile');if(el)el.click();};
window.importJSON=function(input){var file=input.files[0];if(!file)return;var reader=new FileReader();reader.onload=function(e){_processImportText(e.target.result);input.value='';};reader.readAsText(file);};
function _processImportText(text){try{var raw=JSON.parse(text);if(raw&&raw.version===1&&raw.talkScripts&&Array.isArray(raw.mailTemplates)){if(!confirm('現在のデータをインポートしたデータで上書きします。よろしいですか？'))return;localStorage.setItem('talkScripts',JSON.stringify(raw.talkScripts));localStorage.setItem('mailTemplates',JSON.stringify(raw.mailTemplates));if(Array.isArray(raw.updateHistory)&&raw.updateHistory.length>0){_mergeHistory(raw.updateHistory);}location.reload();return;}if(Array.isArray(raw)){if(!confirm('現在のデータをインポートしたデータで上書きします。よろしいですか？'))return;localStorage.setItem('mailTemplates',JSON.stringify(raw));location.reload();return;}var keys=Object.keys(raw);var valid=keys.length>0&&keys.every(function(k){return raw[k].name&&(Array.isArray(raw[k].list)||raw[k].sub);});if(valid){if(!confirm('現在のデータをインポートしたデータで上書きします。よろしいですか？'))return;localStorage.setItem('talkScripts',JSON.stringify(raw));location.reload();return;}alert('ファイルの形式が正しくありません。');}catch(err){alert('読み込みに失敗しました: '+err.message);}}
// 更新履歴をマージ保存（現在にないIDのみ追加、日付降順ソート）
function _mergeHistory(incoming){try{var cur=[];try{var s=localStorage.getItem('updateHistory');if(s)cur=JSON.parse(s);}catch(e){}var inMap={};incoming.forEach(function(h){inMap[h.id]=h;});var kept=cur.filter(function(h){return !inMap[h.id];});var merged=incoming.concat(kept);merged.sort(function(a,b){return(b.date||'').localeCompare(a.date||'');});localStorage.setItem('updateHistory',JSON.stringify(merged));}catch(e){}}

var _namedTabs={};
window.openNamedTab=function(url,name){var tab=_namedTabs[name];if(tab&&!tab.closed){tab.focus();}else{_namedTabs[name]=window.open(url,name);}};
window.toggleSideMenu=function(){var m=document.getElementById('sideMenu');if(!m)return;m.classList.toggle('open');};
window.toggleAccordion=function(id){var body=document.getElementById(id);if(!body)return;var header=body.previousElementSibling;var isOpen=body.classList.contains('open');body.classList.toggle('open',!isOpen);if(header)header.classList.toggle('open',!isOpen);};
window.toggleSubAccordion=function(id){var body=document.getElementById(id);if(!body)return;var header=body.previousElementSibling;var isOpen=body.classList.contains('open');body.classList.toggle('open',!isOpen);if(header)header.classList.toggle('open',!isOpen);};

document.addEventListener('DOMContentLoaded',function(){
  window.renderQuickMenu();
  if(!document.getElementById('_smDarkCSS')){var st=document.createElement('style');st.id='_smDarkCSS';st.textContent='.dark-toggle-sw{position:relative;display:inline-block;width:44px;height:24px;flex-shrink:0}.dark-toggle-sw input{opacity:0;width:0;height:0}.dark-toggle-sl{position:absolute;cursor:pointer;inset:0;background:#ccc;border-radius:24px;transition:.3s}.dark-toggle-sl:before{content:"";position:absolute;height:18px;width:18px;left:3px;bottom:3px;background:#fff;border-radius:50%;transition:.3s}input:checked+.dark-toggle-sl{background:#5c6afc}input:checked+.dark-toggle-sl:before{transform:translateX(20px)}';document.head.appendChild(st);}
  var m=document.getElementById('sideMenu');if(!m)return;
  var saved=localStorage.getItem('darkMode');
  var isDark=saved==='1'||(saved===null&&window.matchMedia&&window.matchMedia('(prefers-color-scheme: dark)').matches);
  function subAcc(id,label,items){var lis=items.map(function(it){return'<li><a href="'+(it.url||'#')+'" target="_blank">'+it.name+'</a></li>';}).join('');return'<li class="sub-acc-item"><div class="sub-acc-header" onclick="toggleSubAccordion(\''+id+'\')"><span class="sub-arrow">▶</span>'+label+'</div><ul class="sub-acc-body" id="'+id+'">'+lis+'</ul></li>';}
  m.innerHTML=
    '<div class="side-section"><div style="display:flex;align-items:center;justify-content:space-between;padding:13px 16px;"><span style="font-size:13px;font-weight:600;">🌙 ダークモード</span><label class="dark-toggle-sw"><input type="checkbox" id="darkModeToggle"'+(isDark?' checked':'')+' onchange="window.applyDarkMode(this.checked)"><span class="dark-toggle-sl"></span></label></div></div>'+
    '<div class="side-section"><div class="side-section-header" onclick="toggleAccordion(\'linkTools\')">🔧 ツール <span class="arrow">▶</span></div><ul class="accordion-body" id="linkTools">'+
      '<li><a href="https://login.mypurecloud.jp/#/authenticate-adv/org/tci-gp1" target="_blank">Genesys</a></li>'+
      '<li><a href="https://ctssvr501.cloud.contact-link.jp/cts_nhk_net/login/index.php" target="_blank">CRM</a></li>'+
      '<li><a href="https://auth.worksmobile.com/login/login?accessUrl=https%3A%2F%2Fcommon.worksmobile.com%2Fproxy%2Fmy" target="_blank">LINE WORKS</a></li>'+
      '<li><a href="https://tci-dcc-support-summaryai02.spiral-site.com/summary_nhk" target="_blank">対話要約AI</a></li>'+
      '<li><a href="http://tci-ami-web16/Speechvisualizer/" target="_blank">SpeechVisualizer</a></li>'+
    '</ul></div>'+
    '<div class="side-section"><div class="side-section-header" onclick="toggleAccordion(\'linkDocs\')">📄 資料 <span class="arrow">▶</span></div><ul class="accordion-body" id="linkDocs">'+

      subAcc('subDocs_gyoumu','業務資料',[{name:'📂 業務資料フォルダを開く',url:'file:///C:/SharedDocs/'},
        {name:'コールセンターについて',          url:'file://tohoku/share/%E6%8B%A0%E7%82%B9/%E4%BB%99%E5%8F%B0%E9%9D%92%E8%91%89/00_%E4%BA%8B%E6%A5%AD%E6%89%80/NGH/%E6%A5%AD%E5%8B%99%E8%B3%87%E6%96%99/%E3%83%9E%E3%83%8B%E3%83%A5%E3%82%A2%E3%83%AB%E9%96%A2%E9%80%A3/NHK%20ONE%20%E9%96%A2%E9%80%A3%E8%B3%87%E6%96%99/%E3%80%90NHK%20ONE%E3%80%91%E3%82%B3%E3%83%BC%E3%83%AB%E3%82%BB%E3%83%B3%E3%82%BF%E3%83%BC%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6_20251129.pdf'},
        {name:'サービス概要・世帯での利用',        url:'file://tohoku/share/%E6%8B%A0%E7%82%B9/%E4%BB%99%E5%8F%B0%E9%9D%92%E8%91%89/00_%E4%BA%8B%E6%A5%AD%E6%89%80/NGH/%E6%A5%AD%E5%8B%99%E8%B3%87%E6%96%99/%E3%83%9E%E3%83%8B%E3%83%A5%E3%82%A2%E3%83%AB%E9%96%A2%E9%80%A3/NHK%20ONE%20%E9%96%A2%E9%80%A3%E8%B3%87%E6%96%99/%E3%80%90NHK%20ONE%E3%80%91%E3%82%B5%E3%83%BC%E3%83%93%E3%82%B9%E6%A6%82%E8%A6%81%E3%83%BB%E4%B8%96%E5%B8%AF%E3%81%A7%E3%81%AE%E5%88%A9%E7%94%A8_20250908.pdf'},
        {name:'学校での利用',                  url:'file://tohoku/share/%E6%8B%A0%E7%82%B9/%E4%BB%99%E5%8F%B0%E9%9D%92%E8%91%89/00_%E4%BA%8B%E6%A5%AD%E6%89%80/NGH/%E6%A5%AD%E5%8B%99%E8%B3%87%E6%96%99/%E3%83%9E%E3%83%8B%E3%83%A5%E3%82%A2%E3%83%AB%E9%96%A2%E9%80%A3/NHK%20ONE%20%E9%96%A2%E9%80%A3%E8%B3%87%E6%96%99/%E3%80%90NHK%20ONE%E3%80%91%E5%AD%A6%E6%A0%A1%E3%81%A7%E3%81%AE%E5%88%A9%E7%94%A8_20260102.pdf'},
        {name:'事業での利用',                  url:'file://tohoku/share/%E6%8B%A0%E7%82%B9/%E4%BB%99%E5%8F%B0%E9%9D%92%E8%91%89/00_%E4%BA%8B%E6%A5%AD%E6%89%80/NGH/%E6%A5%AD%E5%8B%99%E8%B3%87%E6%96%99/%E3%83%9E%E3%83%8B%E3%83%A5%E3%82%A2%E3%83%AB%E9%96%A2%E9%80%A3/NHK%20ONE%20%E9%96%A2%E9%80%A3%E8%B3%87%E6%96%99/%E3%80%90NHK%20ONE%E3%80%91%E4%BA%8B%E6%A5%AD%E3%81%A7%E3%81%AE%E5%88%A9%E7%94%A8_20250904.pdf'},
        {name:'ユーザーお困りポイント',           url:'file://tohoku/share/%E6%8B%A0%E7%82%B9/%E4%BB%99%E5%8F%B0%E9%9D%92%E8%91%89/00_%E4%BA%8B%E6%A5%AD%E6%89%80/NGH/%E6%A5%AD%E5%8B%99%E8%B3%87%E6%96%99/%E3%83%9E%E3%83%8B%E3%83%A5%E3%82%A2%E3%83%AB%E9%96%A2%E9%80%A3/NHK%20ONE%20%E9%96%A2%E9%80%A3%E8%B3%87%E6%96%99/%E3%80%90%E4%B8%96%E5%B8%AF%E3%82%A2%E3%82%AB%E3%82%A6%E3%83%B3%E3%83%88%E3%80%91%E3%83%A6%E3%83%BC%E3%82%B6%E3%83%BC%E3%81%8A%E5%9B%B0%E3%82%8A%E3%83%9D%E3%82%A4%E3%83%B3%E3%83%88_20250908.pdf'},
        {name:'アカウント登録導線説明資料',        url:'file://tohoku/share/%E6%8B%A0%E7%82%B9/%E4%BB%99%E5%8F%B0%E9%9D%92%E8%91%89/00_%E4%BA%8B%E6%A5%AD%E6%89%80/NGH/%E6%A5%AD%E5%8B%99%E8%B3%87%E6%96%99/%E3%83%9E%E3%83%8B%E3%83%A5%E3%82%A2%E3%83%AB%E9%96%A2%E9%80%A3/NHK%20ONE%20%E9%96%A2%E9%80%A3%E8%B3%87%E6%96%99/%E3%80%90NHK%20ONE%E3%80%91%E3%82%A2%E3%82%AB%E3%82%A6%E3%83%B3%E3%83%88%E7%99%BB%E9%8C%B2%E5%B0%8E%E7%B7%9A%E8%AA%AC%E6%98%8E%E8%B3%87%E6%96%99.pdf'},
        {name:'受信料アカウント全国説明会資料',    url:'file://tohoku/share/%E6%8B%A0%E7%82%B9/%E4%BB%99%E5%8F%B0%E9%9D%92%E8%91%89/00_%E4%BA%8B%E6%A5%AD%E6%89%80/NGH/%E6%A5%AD%E5%8B%99%E8%B3%87%E6%96%99/%E3%83%9E%E3%83%8B%E3%83%A5%E3%82%A2%E3%83%AB%E9%96%A2%E9%80%A3/NHK%20ONE%20%E9%96%A2%E9%80%A3%E8%B3%87%E6%96%99/%E3%80%90%E7%A2%BA%E5%AE%9A%E7%89%88%E3%80%9120251110_%E5%8F%97%E4%BF%A1%E6%96%99%E3%82%A2%E3%82%AB%E3%82%A6%E3%83%B3%E3%83%88%E5%85%A8%E5%9B%BD%E8%AA%AC%E6%98%8E%E4%BC%9A%E8%B3%87%E6%96%99_1117%E4%BF%AE%E6%AD%A3.pdf'}
      ])+
      subAcc('subDocs_oubai','応対品質',[{name:'📂 応対品質フォルダを開く',url:'file:///C:/SharedDocs/Quality/'},
        {name:'クレーム対応のポイント',                        url:'file://tohoku/share/%E6%8B%A0%E7%82%B9/%E4%BB%99%E5%8F%B0%E9%9D%92%E8%91%89/00_%E4%BA%8B%E6%A5%AD%E6%89%80/NGH/%E6%A5%AD%E5%8B%99%E8%B3%87%E6%96%99/%E3%83%9E%E3%83%8B%E3%83%A5%E3%82%A2%E3%83%AB%E9%96%A2%E9%80%A3/%E5%BF%9C%E5%AF%BE%E5%93%81%E8%B3%AA/%E3%82%AF%E3%83%AC%E3%83%BC%E3%83%A0%E5%AF%BE%E5%BF%9C%E3%81%AE%E3%83%9D%E3%82%A4%E3%83%B3%E3%83%88.pdf'},
        {name:'わかりやすい伝え方・話し方（ロジカルシンキング）', url:'file://tohoku/share/%E6%8B%A0%E7%82%B9/%E4%BB%99%E5%8F%B0%E9%9D%92%E8%91%89/00_%E4%BA%8B%E6%A5%AD%E6%89%80/NGH/%E6%A5%AD%E5%8B%99%E8%B3%87%E6%96%99/%E3%83%9E%E3%83%8B%E3%83%A5%E3%82%A2%E3%83%AB%E9%96%A2%E9%80%A3/%E5%BF%9C%E5%AF%BE%E5%93%81%E8%B3%AA/%E3%82%8F%E3%81%8B%E3%82%8A%E3%82%84%E3%81%99%E3%81%84%E4%BC%9D%E3%81%88%E6%96%B9%E3%83%BB%E8%A9%B1%E3%81%97%E6%96%B9%EF%BC%88%E3%83%AD%E3%82%B8%E3%82%AB%E3%83%AB%E3%82%B7%E3%83%B3%E3%82%AD%E3%83%B3%E3%82%B0%EF%BC%89.pdf'},
        {name:'高齢者対応',                               url:'file://tohoku/share/%E6%8B%A0%E7%82%B9/%E4%BB%99%E5%8F%B0%E9%9D%92%E8%91%89/00_%E4%BA%8B%E6%A5%AD%E6%89%80/NGH/%E6%A5%AD%E5%8B%99%E8%B3%87%E6%96%99/%E3%83%9E%E3%83%8B%E3%83%A5%E3%82%A2%E3%83%AB%E9%96%A2%E9%80%A3/%E5%BF%9C%E5%AF%BE%E5%93%81%E8%B3%AA/%E9%AB%98%E9%BD%A2%E8%80%85%E5%AF%BE%E5%BF%9C.pdf'}
      ])+

    '</ul></div>'+
    '<div class="side-section"><div class="side-section-header" onclick="toggleAccordion(\'linkSites\')">🌐 関連サイト <span class="arrow">▶</span></div><ul class="accordion-body" id="linkSites">'+
      '<li><a href="https://www.nhk.or.jp/" target="_blank">NHK HP</a></li>'+
      '<li><a href="https://www.nhk.or.jp/nhkone/" target="_blank">NHKONEインフォメーション</a></li>'+
      '<li><a href="https://www.nhk.or.jp/school/" target="_blank">NHK for school</a></li>'+
      '<li><a href="https://www.nhk.or.jp/info/pr/nationwide-nhk/" target="_blank">全国のNHK放送局</a></li>'+
      '<li><a href="https://www.nhk-cs.jp/jushinryo/menjo/window.html" target="_blank">各放送局営業窓口一覧</a></li>'+
      '<li><a href="https://edu-data.jp/" target="_blank">学校コード検索HP</a></li>'+
      '<li><a href="https://www.post.japanpost.jp/zipcode/index.html" target="_blank">郵便局HP</a></li>'+
    '</ul></div>'+
    '<div class="side-section"><div class="side-section-header" onclick="toggleAccordion(\'noticePanel\')">📖フォネティックコード <span class="arrow">▶</span></div>'+
    '<div class="accordion-body" id="noticePanel" style="padding:10px 12px 14px;"><div style="overflow-x:auto;">'+
    '<table style="width:100%;border-collapse:collapse;font-size:11px;min-width:220px;">'+
    '<colgroup><col><col style="width:100px"><col style="width:100px"></colgroup>'+
    '<thead><tr style="background:var(--surface2,#f8f9fa)">'+
    '<th style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;font-weight:700;color:var(--text2,#555)">アルファベット</th>'+
    '<th style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;font-weight:700;color:var(--text2,#555)">読み方①</th>'+
    '<th style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;font-weight:700;color:var(--text2,#555)">読み方②</th>'+
    '</tr></thead>'+
    '<tbody>'+
    '<tr><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">A</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">アメリカ</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">アップル</td></tr>'+
    '<tr><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">B</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">ブラジル</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">ブック</td></tr>'+
    '<tr><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">C</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">チャイナ</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">キャット</td></tr>'+
    '<tr><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">D</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">デンマーク</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">ドクター</td></tr>'+
    '<tr><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">E</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">エジプト</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">イングリッシュ</td></tr>'+
    '<tr><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">F</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">フランス</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)"></td></tr>'+
    '<tr><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">G</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">グーグル</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)"></td></tr>'+
    '<tr><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">H</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">ホンコン</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)"></td></tr>'+
    '<tr><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">I</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">イタリア</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)"></td></tr>'+
    '<tr><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">J</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">ジャパン</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)"></td></tr>'+
    '<tr><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">K</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">キング</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)"></td></tr>'+
    '<tr><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">L</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">ロンドン</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)"></td></tr>'+
    '<tr><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">M</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">メキシコ</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)"></td></tr>'+
    '<tr><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">N</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">ニューヨーク</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)"></td></tr>'+
    '<tr><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">O</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">大阪</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)"></td></tr>'+
    '<tr><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">P</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">パリ</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)"></td></tr>'+
    '<tr><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">Q</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">クイーン</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)"></td></tr>'+
    '<tr><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">R</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">ローマ</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)"></td></tr>'+
    '<tr><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">S</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">スター</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)"></td></tr>'+
    '<tr><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">T</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">東京</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)"></td></tr>'+
    '<tr><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">U</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">USA</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)"></td></tr>'+
    '<tr><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">V</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">ヴィクトリー</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)"></td></tr>'+
    '<tr><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">W</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">ワールド</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)"></td></tr>'+
    '<tr><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">X</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">エックス線</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)"></td></tr>'+
    '<tr><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">Y</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">ヤフー</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)"></td></tr>'+
    '<tr><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">Z</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">ゼブラ</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)"></td></tr>'+
    '<tr><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">-</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">ハイフン</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)"></td></tr>'+
    '<tr><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">_</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">アンダーバー</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)"></td></tr>'+
    '</tbody></table></div></div></div>'+
    '<div class="side-section" id="historySideSection"><div class="side-section-header" onclick="toggleAccordion(\'historyPanel\')">📝 更新履歴 <span class="arrow">▶</span></div>'+
    '<div class="accordion-body" id="historyPanel" style="padding:0;"></div></div>';

  // 更新履歴をlocalStorageから読み込んでテーブル描画
  window.renderHistory = function(){
    var panel = document.getElementById('historyPanel');
    if(!panel) return;
    var raw = null;
    try{ raw = localStorage.getItem('updateHistory'); }catch(e){}
    var arr = [];
    if(raw){ try{ arr = JSON.parse(raw); }catch(e){} }
    // localStorageにデータがなければデフォルト初期データを使用
    if(!arr || arr.length === 0){
      arr = [{id:'h_default_1', content:'初版作成', author:'菅原', approver:'-', date:'2026/03/08'}];
    }
    var td = function(v){ return '<td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542);word-break:break-all;">'+(v||'-')+'</td>'; };
    var rows = arr.map(function(e){ return '<tr>'+td(e.content)+td(e.author)+td(e.approver)+td(e.date)+'</tr>'; }).join('');
    panel.innerHTML =
      '<div style="padding:10px 12px 14px;"><div style="overflow-x:auto;">'+
      '<table style="width:100%;border-collapse:collapse;font-size:11px;min-width:280px;">'+
      '<colgroup><col><col style="width:52px"><col style="width:52px"><col style="width:82px"></colgroup>'+
      '<thead><tr style="background:var(--surface2,#f8f9fa)">'+
      '<th style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;font-weight:700;color:var(--text2,#555)">更新内容</th>'+
      '<th style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;font-weight:700;color:var(--text2,#555)">更新者</th>'+
      '<th style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;font-weight:700;color:var(--text2,#555)">承認者</th>'+
      '<th style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;font-weight:700;color:var(--text2,#555)">更新日</th>'+
      '</tr></thead>'+
      '<tbody>'+rows+'</tbody></table></div></div>';
  };
  // localStorageの変更を他タブから受け取って再描画
  window.addEventListener('storage', function(e){
    if(e.key === 'updateHistory') window.renderHistory();
  });
  window.renderHistory();

  document.addEventListener('click',function(e){
    if(!e.target.closest('.quick-copy-area')){var qm=document.getElementById('quickMenu');if(qm)qm.classList.remove('open');}
    var btn=document.getElementById('menuBtn');
    if(!m.contains(e.target)&&btn&&e.target!==btn&&!btn.contains(e.target)){m.classList.remove('open');}
  });
});

var ADMIN_PW='admin1234';var _adminUnlocked=false;
window.openAdminWithAuth=function(){if(_adminUnlocked){sessionStorage.setItem('adminAuth','1');window.openNamedTab('admin.html','adminTab');return;}var pw=prompt('管理画面のパスワードを入力してください');if(pw===null)return;if(pw===ADMIN_PW){_adminUnlocked=true;sessionStorage.setItem('adminAuth','1');window.openNamedTab('admin.html','adminTab');}else{alert('パスワードが違います');}};
