// ===== ヒアリングチェックシート =====
// sessionStorage で状態を永続化（タブを閉じるまで保持・リセットでクリア）

var HEARING_KEY = 'hearingState_v4';

var DEFAULT_STATE = {
  usage: null,
  isMigration: null,
  oldPlusId: null,
  migMailConfirmed: null,
  migMailUsable: null,
  isAccountPerson: null,
  sAccountCreated: null,
  authCodeIssue: null,   // '移行エラーメール受信'|'新規エラーメール受信'|'Jアカ重複メール受信'|'メール受信なし'
  authCodeResult: null,  // '認証コード受信'|'認証コード未着(任意情報なし)'|'認証コード未着(任意情報あり)'
  jAccountCreated: null,
  sjLinked: null,        // '連携済み'|'未連携'|'再連携必要'|'ログイン不可'
  sjLoginlessResult: null, // ログイン不可時の認証コード確認結果
  devices: {},
  mailDomain: '',
  mailDomainManual: '',
  cbMistake: false,
  cbReject: false,
  cbSpam: false
};

var DEVICE_LIST = ['iPhone', 'Android', 'タブレット', 'PC', 'TV'];
var DEVICE_DETAIL_OPTIONS = {
  'iPhone':    ['Web', 'アプリ', 'Web,アプリ両方'],
  'Android':   ['Web', 'アプリ', 'Web,アプリ両方'],
  'タブレット': ['Web', 'アプリ', 'Web,アプリ両方'],
  'PC':        ['Windows', 'Mac', 'ChromeBook'],
  'TV':        []
};

// ===== 状態の読み込み・保存 =====
function loadHearingState() {
  try {
    var saved = sessionStorage.getItem(HEARING_KEY);
    if (saved) {
      var parsed = JSON.parse(saved);
      var devices = {};
      DEVICE_LIST.forEach(function(d) {
        devices[d] = (parsed.devices && parsed.devices[d]) ? parsed.devices[d] : { selected: false, detail: '' };
      });
      parsed.devices = devices;
      return Object.assign({}, DEFAULT_STATE, parsed);
    }
  } catch(e) {}
  var state = JSON.parse(JSON.stringify(DEFAULT_STATE));
  DEVICE_LIST.forEach(function(d) { state.devices[d] = { selected: false, detail: '' }; });
  return state;
}

function saveHearingState() {
  try { sessionStorage.setItem(HEARING_KEY, JSON.stringify(hearingState)); } catch(e) {}
}

var hearingState = loadHearingState();
var hearingPanelOpen = false;

// ===== パネル開閉 =====
window.toggleHearingPanel = function() {
  hearingPanelOpen = !hearingPanelOpen;
  var panel = document.getElementById('hearingPanel');
  var btn   = document.getElementById('hearingToggleBtn');
  if (panel) panel.classList.toggle('open', hearingPanelOpen);
  if (btn)   btn.textContent = hearingPanelOpen ? '＞' : '＜';
};

// ===== リセット =====
window.resetHearing = function() {
  hearingState = JSON.parse(JSON.stringify(DEFAULT_STATE));
  DEVICE_LIST.forEach(function(d) { hearingState.devices[d] = { selected: false, detail: '' }; });
  saveHearingState();
  renderHearing();
};

// ===== 値セット（連鎖リセット付き） =====
window.setHearing = function(field, value) {
  // 連鎖リセット
  var resets = {
    usage:           ['isMigration','oldPlusId','migMailConfirmed','migMailUsable','isAccountPerson','sAccountCreated','authCodeIssue','authCodeResult','jAccountCreated','sjLinked','sjLoginlessResult'],
    isMigration:     ['oldPlusId','migMailConfirmed','migMailUsable','sAccountCreated','authCodeIssue','authCodeResult','jAccountCreated','sjLinked','sjLoginlessResult'],
    oldPlusId:       ['migMailConfirmed','migMailUsable'],
    migMailConfirmed:['migMailUsable'],
    isAccountPerson: ['sAccountCreated','authCodeIssue','authCodeResult','jAccountCreated','sjLinked','sjLoginlessResult'],
    sAccountCreated: ['authCodeIssue','authCodeResult','jAccountCreated','sjLinked','sjLoginlessResult'],
    authCodeIssue:   ['authCodeResult'],
    sjLinked:        ['jAccountCreated','sjLoginlessResult'],
    jAccountCreated: []
  };
  if (resets[field]) {
    resets[field].forEach(function(f) { hearingState[f] = null; });
  }
  hearingState[field] = value;
  saveHearingState();
  renderHearing();
};

window.toggleHearingDevice = function(device) {
  var d = hearingState.devices[device];
  d.selected = !d.selected;
  if (!d.selected) d.detail = '';
  saveHearingState();
  renderHearing();
};

window.setHearingDeviceDetail = function(device, value) {
  hearingState.devices[device].detail = value;
  saveHearingState();
  renderHearing();
};

window.onHearingDomainChange = function() {
  var sel = document.getElementById('hearingDomainSel');
  if (!sel) return;
  hearingState.mailDomain = sel.value;
  var mw = document.getElementById('hearingDomainManualWrap');
  if (mw) mw.style.display = sel.value === '__manual__' ? 'block' : 'none';
  saveHearingState();
  renderHearingSummary();
};

window.onHearingDomainManualInput = function() {
  var inp = document.getElementById('hearingDomainManual');
  if (!inp) return;
  hearingState.mailDomainManual = inp.value;
  saveHearingState();
  renderHearingSummary();
};

window.onHearingCheckChange = function(field) {
  var el = document.getElementById('hearingCb_' + field);
  if (!el) return;
  hearingState[field] = el.checked;
  saveHearingState();
  renderHearingSummary();
};

// ===== ボタン生成ヘルパー =====
function boolBtns(field, value, labelTrue, labelFalse) {
  var t = '<button class="hr-btn' + (value === true  ? ' active' : '') + '" onclick="setHearing(\'' + field + '\',true)">'  + labelTrue  + '</button>';
  var f = '<button class="hr-btn' + (value === false ? ' active' : '') + '" onclick="setHearing(\'' + field + '\',false)">' + labelFalse + '</button>';
  return t + f;
}

function strBtns(field, value, items) {
  return items.map(function(item) {
    var active = value === item.v ? ' active' : '';
    return '<button class="hr-btn' + active + '" onclick="setHearing(\'' + field + '\',\'' + item.v + '\')">' + item.l + '</button>';
  }).join('');
}

function row(label, content, extraClass) {
  return '<div class="hr-row' + (extraClass ? ' ' + extraClass : '') + '">'
       + '<div class="hr-label">■' + label + '</div>'
       + '<div class="hr-btns">' + content + '</div>'
       + '</div>';
}

function esc(s) {
  return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ===== 対応方針の自動導出 =====
function calcPolicies(s) {
  var policies = [];

  // 旧プラスID：いいえ
  if (s.usage === '世帯' && s.isMigration === true && s.oldPlusId === false)
    policies.push('移行対象者ではありませんので新規登録を案内してください');

  // 移行案内メール未確認
  if (s.usage === '世帯' && s.isMigration === true && s.oldPlusId === true && s.migMailConfirmed === false)
    policies.push('ガイダンス2で確認を依頼してください');

  // 移行案内メールアドレス使用不可
  if (s.usage === '世帯' && s.isMigration === true && s.oldPlusId === true && s.migMailConfirmed === true && s.migMailUsable === false)
    policies.push('ガイダンス2で連携解除を依頼してください');

  // S-J連携：再連携必要
  if (s.sjLinked === '再連携必要')
    policies.push('ガイダンス2で連携解除後の再登録となることを案内してください');

  // 認証コード受信（sAccountCreated=false ルート）
  if (s.sAccountCreated === false && s.authCodeResult === '認証コード受信')
    policies.push('PW変更後、ログインしてご利用いただくようご案内ください。');

  // ログイン不可 → 認証コード受信
  if (s.sjLinked === 'ログイン不可' && s.sjLoginlessResult === '認証コード受信')
    policies.push('PW変更後、ログインしてご利用いただくようご案内ください。');

  // Jアカ重複メール受信
  if (s.authCodeIssue === 'Jアカ重複メール受信')
    policies.push('ガイダンス2で受信料アカウントの登録状況確認を依頼してください。');

  // 移行エラーメール × 任意情報なし
  if (s.authCodeIssue === '移行エラーメール受信' && s.authCodeResult === '認証コード未着(任意情報なし)')
    policies.push('入力されたアドレスが登録表記との不一致等の理由で移行対象のアドレスではない可能性があるため、ガイダンス2で確認を依頼してください。');

  // 移行エラーメール × 任意情報あり
  if (s.authCodeIssue === '移行エラーメール受信' && s.authCodeResult === '認証コード未着(任意情報あり)')
    policies.push('任意情報を失念してしまうとアカウントの復旧ができないため、ガイダンス2で連携解除後の新規登録となることをご案内ください。');

  // 新規エラーメール × 任意情報なし
  if (s.authCodeIssue === '新規エラーメール受信' && s.authCodeResult === '認証コード未着(任意情報なし)')
    policies.push('入力されたアドレスが移行の対象である可能性があるため、移行手続きをお試しいただくようご案内ください。');

  // ★新規追加：世帯 / 移行対象者:いいえ / 新規エラーメール × 任意情報あり
  if (s.usage === '世帯' && s.isMigration === false && s.authCodeIssue === '新規エラーメール受信' && s.authCodeResult === '認証コード未着(任意情報あり)')
    policies.push('このメールアドレスでSアカは作成済みです\n任意情報を失念してしまうとアカウントの復旧ができません\n作成済みのSアカは3か月未ログインで自動削除となり、そこから1か月経過後より同アドレスの利用が可能となります\n別メアドでのSアカ新規に不承の場合は、当窓口でのSアカ削除を承ってください。');

  // ★新規追加：世帯 / 移行対象者:はい / 移行ルート完走 / 新規エラーメール × 任意情報あり
  if (s.usage === '世帯' && s.isMigration === true && s.oldPlusId === true && s.migMailConfirmed === true && s.migMailUsable === true && s.sAccountCreated === false && s.authCodeIssue === '新規エラーメール受信' && s.authCodeResult === '認証コード未着(任意情報あり)')
    policies.push('このメールアドレスでSアカは作成済みです\n任意情報を失念してしまうとアカウントの復旧ができません\nガイダンス2で連携解除後の新規登録となることをご案内ください。');

  // 上記2条件が重複しないよう：世帯/移行あり以外の新規エラー×任意情報あり
  var alreadyHandled =
    (s.usage === '世帯' && s.isMigration === false && s.authCodeIssue === '新規エラーメール受信' && s.authCodeResult === '認証コード未着(任意情報あり)') ||
    (s.usage === '世帯' && s.isMigration === true && s.oldPlusId === true && s.migMailConfirmed === true && s.migMailUsable === true && s.sAccountCreated === false && s.authCodeIssue === '新規エラーメール受信' && s.authCodeResult === '認証コード未着(任意情報あり)');

  // 新規エラーメール × 任意情報あり × 連携済み（上記以外のケース）
  if (!alreadyHandled && s.authCodeIssue === '新規エラーメール受信' && s.authCodeResult === '認証コード未着(任意情報あり)' && s.sjLinked === '連携済み')
    policies.push('任意情報を失念してしまうとアカウントの復旧ができないため、ガイダンス2で連携解除後の新規登録となることをご案内ください。');

  // 新規エラーメール × 任意情報あり × 未連携（上記以外のケース）
  if (!alreadyHandled && s.authCodeIssue === '新規エラーメール受信' && s.authCodeResult === '認証コード未着(任意情報あり)' && s.sjLinked === '未連携')
    policies.push('任意情報を失念してしまうとアカウントの復旧ができないため、別のメールアドレスで新規登録となることをご案内ください。※アドレスが1つしかないという申告であれば、3か月未ログインで自動削除、そこから1か月経過後から同アドレスが使用可能となることをご案内ください。（不承の場合は、当窓口での削除から1か月経過後に同アドレスで新規登録をしていただくようご案内ください）');

  // ★新規追加：世帯 / 移行対象者:いいえ / メール受信なし / 全確認項目チェック済み
  if (s.usage === '世帯' && s.isMigration === false && s.authCodeIssue === 'メール受信なし' && s.cbMistake === true && s.cbReject === true && s.cbSpam === true)
    policies.push('クライアントエスカレーションの案件です');

  return policies;
}

// ===== メイン描画 =====
function renderHearing() {
  var el = document.getElementById('hearingContent');
  if (!el) return;
  var s = hearingState;
  var h = '';

  // ■用途
  h += row('用途',
    strBtns('usage', s.usage, [{l:'世帯',v:'世帯'},{l:'学校',v:'学校'},{l:'事業',v:'事業'}]));

  // ■移行対象者（世帯のみ）
  if (s.usage === '世帯') {
    h += row('移行対象者ですか？', boolBtns('isMigration', s.isMigration, 'はい', 'いいえ'));
  }

  // ■旧プラスID（移行対象者:はい）
  if (s.usage === '世帯' && s.isMigration === true) {
    h += row('2025/8/15時点で旧プラスのIDは発行されていましたか？',
      boolBtns('oldPlusId', s.oldPlusId, 'はい(わからない)', 'いいえ'));
  }

  // ■移行案内メール確認（旧プラスID:はい）
  if (s.usage === '世帯' && s.isMigration === true && s.oldPlusId === true) {
    h += row('7月/9月/10月に送信している移行案内メールは確認されていますか？',
      boolBtns('migMailConfirmed', s.migMailConfirmed, 'はい', 'いいえ(わからない)'));
  }

  // ■移行案内メールアドレス使用可能（確認:はい）
  if (s.usage === '世帯' && s.isMigration === true && s.oldPlusId === true && s.migMailConfirmed === true) {
    h += row('移行案内メールを受信しているメールアドレスは現在も使用可能ですか？',
      boolBtns('migMailUsable', s.migMailUsable, 'はい', 'いいえ'));
  }

  // ■アカウント担当者（学校・事業のみ）
  if (s.usage === '学校' || s.usage === '事業') {
    h += row('入電者はアカウント担当者ですか？',
      boolBtns('isAccountPerson', s.isAccountPerson, 'はい', 'いいえ'));
  }

  // ■Sアカ（用途選択後）
  if (s.usage !== null) {
    h += row('Sアカは作成済みですか？',
      boolBtns('sAccountCreated', s.sAccountCreated, 'はい', 'いいえ'));
  }

  // ■認証コード未着（Sアカ:いいえ）
  if (s.sAccountCreated === false) {
    h += row('認証コード未着ですか？',
      strBtns('authCodeIssue', s.authCodeIssue, [
        {l:'移行エラーメール受信',   v:'移行エラーメール受信'},
        {l:'新規エラーメール受信',   v:'新規エラーメール受信'},
        {l:'Jアカ重複メール受信',   v:'Jアカ重複メール受信'},
        {l:'メール受信なし',         v:'メール受信なし'}
      ]));
  }

  // ■認証コード確認（移行エラーメール or 新規エラーメール）
  if (s.authCodeIssue === '移行エラーメール受信' || s.authCodeIssue === '新規エラーメール受信') {
    h += row('ログイン画面下部「PWをお忘れの方はこちら」から進んで認証コードが届くか',
      strBtns('authCodeResult', s.authCodeResult, [
        {l:'認証コード受信',                  v:'認証コード受信'},
        {l:'認証コード未着(任意情報なし)',     v:'認証コード未着(任意情報なし)'},
        {l:'認証コード未着(任意情報あり)',     v:'認証コード未着(任意情報あり)'}
      ]));
  }

  // ■Sアカあり → S-J連携確認
  // 条件1: 全ルート（世帯 && Sアカ:はい）→ S-J連携を最初に表示
  // ※ 移行ルート (isMigration=true, oldPlusId=true, migMailConfirmed=true, migMailUsable=true) の場合も含む
  if (s.usage === '世帯' && s.sAccountCreated === true) {
    h += row('S-J連携済みですか？',
      strBtns('sjLinked', s.sjLinked, [
        {l:'連携済み',                  v:'連携済み'},
        {l:'未連携',                    v:'未連携'},
        {l:'未確認（再連携が必要です）', v:'再連携必要'},
        {l:'ログイン不可',              v:'ログイン不可'}
      ]));
  }

  // ■ログイン不可 → 認証コード確認
  if (s.usage === '世帯' && s.sAccountCreated === true && s.sjLinked === 'ログイン不可') {
    h += row('ログイン画面下部「PWをお忘れの方はこちら」から進んで認証コードが届くか',
      strBtns('sjLoginlessResult', s.sjLoginlessResult, [
        {l:'認証コード受信',                  v:'認証コード受信'},
        {l:'認証コード未着(任意情報なし)',     v:'認証コード未着(任意情報なし)'},
        {l:'認証コード未着(任意情報あり)',     v:'認証コード未着(任意情報あり)'}
      ]));
  }

  // ■Jアカ（世帯 && Sアカ:はい && (未連携 or 再連携必要)）
  // ※ 移行ルートの場合は isMigration=true && ... && migMailUsable=true の条件も必要
  var showJAccount = false;
  if (s.usage === '世帯' && s.sAccountCreated === true) {
    if (s.isMigration === true && s.oldPlusId === true && s.migMailConfirmed === true && s.migMailUsable === true) {
      // 移行ルート：未連携または再連携必要のときのみ表示
      showJAccount = (s.sjLinked === '未連携' || s.sjLinked === '再連携必要');
    } else if (s.isMigration !== true) {
      // 非移行ルート：未連携または再連携必要のときのみ表示
      showJAccount = (s.sjLinked === '未連携' || s.sjLinked === '再連携必要');
    }
    // 連携済み・ログイン不可では表示しない
  }
  if (showJAccount) {
    h += row('Jアカは作成済みですか？',
      boolBtns('jAccountCreated', s.jAccountCreated, 'はい', 'いいえ'));
  }

  // ■操作環境
  var devBtns = '<div class="hr-device-btns">';
  DEVICE_LIST.forEach(function(device) {
    var d = s.devices[device];
    devBtns += '<button class="hr-device-btn' + (d.selected ? ' active' : '') + '" onclick="toggleHearingDevice(\'' + device + '\')">' + device + '</button>';
  });
  devBtns += '</div>';
  DEVICE_LIST.forEach(function(device) {
    var d = s.devices[device];
    var opts = DEVICE_DETAIL_OPTIONS[device];
    if (d.selected && opts && opts.length > 0) {
      devBtns += '<div class="hr-device-detail"><span class="hr-device-detail-label">' + device + '：</span>';
      opts.forEach(function(opt) {
        devBtns += '<button class="hr-detail-btn' + (d.detail === opt ? ' active' : '') + '" onclick="setHearingDeviceDetail(\'' + device + '\',\'' + opt + '\')">' + opt + '</button>';
      });
      devBtns += '</div>';
    }
  });
  h += row('操作環境', devBtns, 'hr-row-devices');

  // ---- メール未着調査（メール受信なしの場合のみ表示） ----
  if (s.authCodeIssue === 'メール受信なし') {
    h += '<div class="hr-divider">メール未着調査</div>';

    var dv = s.mailDomain;
    h += '<div class="hr-row">'
       + '<div class="hr-label">■ドメイン（＠以降）</div>'
       + '<select id="hearingDomainSel" class="hr-select" onchange="onHearingDomainChange()">'
       + '<option value="">選択してください</option>'
       + mkOpt('@docomo.ne.jp',   dv)
       + mkOpt('@softbank.ne.jp', dv)
       + mkOpt('@i.softbank.jp',  dv)
       + mkOpt('@ezweb.ne.jp',    dv)
       + mkOpt('@au.com',         dv)
       + mkOpt('@gmail.com',      dv)
       + mkOpt('@yahoo.co.jp',    dv)
       + mkOpt('@outlook.com',    dv)
       + '<option value="__manual__"' + (dv === '__manual__' ? ' selected' : '') + '>その他（手入力）</option>'
       + '</select>'
       + '<div id="hearingDomainManualWrap" style="display:' + (dv === '__manual__' ? 'block' : 'none') + ';margin-top:6px;">'
       + '<input id="hearingDomainManual" type="text" class="hr-text-input" placeholder="例）@example.com" value="' + esc(s.mailDomainManual) + '" oninput="onHearingDomainManualInput()">'
       + '</div></div>';

    h += '<div class="hr-row">'
       + '<div class="hr-label">■確認項目</div>'
       + mkChk('cbMistake', s.cbMistake, 'メールアドレスの入力ミス')
       + mkChk('cbReject',  s.cbReject,  '受信拒否')
       + mkChk('cbSpam',    s.cbSpam,    '迷惑メールフィルター')
       + '</div>';
  }

  // サマリーエリア
  h += '<div id="hearingSummaryArea"></div>';

  el.innerHTML = h;
  renderHearingSummary();
}

function mkOpt(val, selected) {
  return '<option value="' + val + '"' + (selected === val ? ' selected' : '') + '>' + val + '</option>';
}
function mkChk(id, checked, label) {
  return '<label class="hr-check-label"><input id="hearingCb_' + id + '" type="checkbox" ' + (checked ? 'checked' : '') + ' onchange="onHearingCheckChange(\'' + id + '\')">' + ' ' + label + '</label>';
}

// ===== サマリー描画 =====
function renderHearingSummary() {
  var area = document.getElementById('hearingSummaryArea');
  if (!area) return;
  var s = hearingState;
  var rows = [];

  if (s.usage) rows.push(['用途', s.usage, '']);

  if (s.usage === '世帯') {
    if (s.isMigration !== null)
      rows.push(['移行対象者', s.isMigration ? 'はい' : 'いいえ', 'bool']);
    if (s.isMigration === true) {
      if (s.oldPlusId !== null)
        rows.push(['旧プラスID発行', s.oldPlusId ? 'はい(わからない)' : 'いいえ', 'bool']);
      if (s.oldPlusId === true) {
        if (s.migMailConfirmed !== null)
          rows.push(['移行案内メール確認', s.migMailConfirmed ? 'はい' : 'いいえ(わからない)', 'bool']);
        if (s.migMailConfirmed === true && s.migMailUsable !== null)
          rows.push(['メールアドレス使用可', s.migMailUsable ? 'はい' : 'いいえ', 'bool']);
      }
    }
  }

  if ((s.usage === '学校' || s.usage === '事業') && s.isAccountPerson !== null)
    rows.push(['アカウント担当者', s.isAccountPerson ? 'はい' : 'いいえ', 'bool']);

  if (s.sAccountCreated !== null)
    rows.push(['Sアカ作成済み', s.sAccountCreated ? 'はい' : 'いいえ', 'bool']);

  if (s.sAccountCreated === false && s.authCodeIssue !== null)
    rows.push(['認証コード未着', s.authCodeIssue, '']);

  if (s.sAccountCreated === false && s.authCodeResult !== null)
    rows.push(['認証コード確認', s.authCodeResult, '']);

  if (s.usage === '世帯' && s.sAccountCreated === true && s.sjLinked !== null)
    rows.push(['S-J連携', s.sjLinked === '再連携必要' ? '未確認（再連携必要）' : s.sjLinked,
      s.sjLinked === '連携済み' ? 'yes' : (s.sjLinked === 'ログイン不可' ? 'no' : 'no')]);

  if (s.usage === '世帯' && s.sAccountCreated === true && s.sjLinked === 'ログイン不可' && s.sjLoginlessResult !== null)
    rows.push(['認証コード確認(ログイン不可)', s.sjLoginlessResult, '']);

  if (s.usage === '世帯' && s.sAccountCreated === true && (s.sjLinked === '未連携' || s.sjLinked === '再連携必要') && s.jAccountCreated !== null)
    rows.push(['Jアカ作成済み', s.jAccountCreated ? 'はい' : 'いいえ', 'bool']);

  // 操作環境
  var envParts = [];
  DEVICE_LIST.forEach(function(device) {
    var d = s.devices[device];
    if (d.selected) envParts.push(d.detail ? device + '(' + d.detail + ')' : device);
  });
  if (envParts.length) rows.push(['操作環境', envParts.join('、'), '']);

  // メール未着（メール受信なしのみ）
  if (s.authCodeIssue === 'メール受信なし') {
    var domain = s.mailDomain === '__manual__' ? s.mailDomainManual : s.mailDomain;
    if (domain) rows.push(['ドメイン', domain, '']);
    var checks = [];
    if (s.cbMistake) checks.push('入力ミス');
    if (s.cbReject)  checks.push('受信拒否');
    if (s.cbSpam)    checks.push('迷惑メールフィルター');
    if (checks.length) rows.push(['確認項目', checks.join('、'), '']);
  }

  // 対応方針
  var policies = calcPolicies(s);

  if (rows.length === 0 && policies.length === 0) { area.innerHTML = ''; return; }

  var h = '<div class="hr-summary"><div class="hr-summary-title">📋 ヒアリング内容</div><div class="hr-summary-rows">';
  rows.forEach(function(r) {
    var label = r[0], val = r[1], type = r[2];
    var valClass = 'hr-sum-val';
    if (type === 'bool') {
      if (val === 'はい' || val === 'はい(わからない)') valClass += ' hr-sum-yes';
      else valClass += ' hr-sum-no';
    }
    if (type === 'yes') valClass += ' hr-sum-yes';
    if (type === 'no')  valClass += ' hr-sum-no';
    h += '<div class="hr-summary-row"><span class="hr-sum-label">' + esc(label) + '</span><span class="' + valClass + '">' + esc(val) + '</span></div>';
  });
  h += '</div>';

  // 対応方針（複数対応）
  if (policies.length > 0) {
    h += '<div id="hearingPolicyArea">';
    policies.forEach(function(p) {
      // 改行を <br> に変換
      var pHtml = esc(p).replace(/\n/g, '<br>');
      h += '<div class="hr-summary-policy"><span class="hr-policy-icon">📌</span><span class="hr-policy-text">対応方針：' + pHtml + '</span></div>';
    });
    h += '</div>';
  }

  h += '</div>';
  area.innerHTML = h;

  // 対応方針が出たら自動スクロール
  if (policies.length > 0) {
    setTimeout(function() {
      var policyEl = document.getElementById('hearingPolicyArea');
      if (policyEl) policyEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }, 80);
  }
}

// ===== コピー機能 =====
window.copyHearingText = function() {
  var s = hearingState;
  var lines = [];

  if (s.usage) lines.push('用途：' + s.usage);
  if (s.usage === '世帯') {
    if (s.isMigration !== null) lines.push('移行対象者：' + (s.isMigration ? 'はい' : 'いいえ'));
    if (s.isMigration === true) {
      if (s.oldPlusId !== null) lines.push('旧プラスID発行：' + (s.oldPlusId ? 'はい(わからない)' : 'いいえ'));
      if (s.oldPlusId === true) {
        if (s.migMailConfirmed !== null) lines.push('移行案内メール確認：' + (s.migMailConfirmed ? 'はい' : 'いいえ(わからない)'));
        if (s.migMailConfirmed === true && s.migMailUsable !== null) lines.push('メールアドレス使用可：' + (s.migMailUsable ? 'はい' : 'いいえ'));
      }
    }
  }
  if ((s.usage === '学校' || s.usage === '事業') && s.isAccountPerson !== null)
    lines.push('アカウント担当者：' + (s.isAccountPerson ? 'はい' : 'いいえ'));
  if (s.sAccountCreated !== null) lines.push('Sアカ作成済み：' + (s.sAccountCreated ? 'はい' : 'いいえ'));
  if (s.sAccountCreated === false && s.authCodeIssue) lines.push('認証コード未着：' + s.authCodeIssue);
  if (s.sAccountCreated === false && s.authCodeResult) lines.push('認証コード確認：' + s.authCodeResult);
  if (s.usage === '世帯' && s.sAccountCreated === true && s.sjLinked)
    lines.push('S-J連携：' + (s.sjLinked === '再連携必要' ? '未確認（再連携必要）' : s.sjLinked));
  if (s.usage === '世帯' && s.sAccountCreated === true && s.sjLinked === 'ログイン不可' && s.sjLoginlessResult)
    lines.push('認証コード確認(ログイン不可)：' + s.sjLoginlessResult);
  if (s.usage === '世帯' && s.sAccountCreated === true && (s.sjLinked === '未連携' || s.sjLinked === '再連携必要') && s.jAccountCreated !== null)
    lines.push('Jアカ作成済み：' + (s.jAccountCreated ? 'はい' : 'いいえ'));

  var envParts = [];
  DEVICE_LIST.forEach(function(device) {
    var d = s.devices[device];
    if (d.selected) envParts.push(d.detail ? device + '(' + d.detail + ')' : device);
  });
  if (envParts.length) lines.push('操作環境：' + envParts.join('、'));

  if (s.authCodeIssue === 'メール受信なし') {
    var domain = s.mailDomain === '__manual__' ? s.mailDomainManual : s.mailDomain;
    if (domain) lines.push('ドメイン：' + domain);
    var checks = [];
    if (s.cbMistake) checks.push('入力ミス');
    if (s.cbReject)  checks.push('受信拒否');
    if (s.cbSpam)    checks.push('迷惑メールフィルター');
    if (checks.length) lines.push('確認項目：' + checks.join('、'));
  }

  var policies = calcPolicies(s);
  policies.forEach(function(p) { lines.push('対応方針：' + p); });

  if (lines.length === 0) { showHearingCopyToast('コピーする内容がありません', true); return; }

  var text = lines.join('\n');
  var done = function() { showHearingCopyToast('ヒアリング内容をコピーしました', false); };
  if (navigator.clipboard) {
    navigator.clipboard.writeText(text).then(done).catch(function() { fallbackCopyH(text); done(); });
  } else { fallbackCopyH(text); done(); }
};

function fallbackCopyH(text) {
  var el = document.createElement('textarea');
  el.value = text;
  document.body.appendChild(el);
  el.select();
  document.execCommand('copy');
  document.body.removeChild(el);
}

function showHearingCopyToast(msg, isError) {
  var toast = document.getElementById('hearingCopyToast');
  if (!toast) return;
  toast.textContent = msg;
  toast.className = 'hearing-copy-toast show' + (isError ? ' error' : '');
  clearTimeout(toast._t);
  toast._t = setTimeout(function() { toast.className = 'hearing-copy-toast'; }, 2000);
}

// グローバル公開（admin.html など外部から呼び出し可能にする）
window.renderHearing = renderHearing;
window.resetHearing = function() {
  hearingState = JSON.parse(JSON.stringify(DEFAULT_STATE));
  try { DEVICE_LIST.forEach(function(d){hearingState.devices[d]={selected:false,detail:''};});} catch(e){}
  saveHearingState(); renderHearing();
};
window.copyHearingText = copyHearingText;

// DOMContentLoaded 済みの場合も含めて確実に初回描画
// admin.html では body末尾script読み込み時にはDOMContentLoadedは既に完了している
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', function() {
    if (document.getElementById('hearingContent')) renderHearing();
  });
} else {
  // DOMContentLoaded 済み
  if (document.getElementById('hearingContent')) renderHearing();
}
