// =====================================================
// データ読み込み
// =====================================================
let scripts;
try {
  const saved = localStorage.getItem('talkScripts');
  scripts = saved ? JSON.parse(saved) : {};
} catch(e) { scripts = {}; }

let historyStack = [];
let forwardStack  = [];

const contentArea = document.getElementById("contentArea");
const closingText = document.getElementById("closingText");

// =====================================================
// ホーム表示
// =====================================================
function renderHome() {
  let buttonsHtml = '';
  Object.entries(scripts).forEach(([key, cat]) => {
    const color = cat.color || '#3742fa';
    buttonsHtml += `<button onclick="selectUsage('${key}')" style="background:${color}">${cat.name}</button>`;
  });
  contentArea.innerHTML = `
    <h2>用途を選択してください</h2>
    <div class="button-grid">${buttonsHtml}</div>
  `;
}

// =====================================================
// 状態変数
// =====================================================
let currentType      = null;
let currentSubKey    = null;
let currentOpenIndex = null;
let stepHistory      = [];
let visitedSteps     = [];

// =====================================================
// 用途選択
// =====================================================
function selectUsage(type) {
  historyStack.push(contentArea.innerHTML);
  forwardStack = [];
  currentType      = type;
  currentSubKey    = null;
  currentOpenIndex = null;
  const cat = scripts[type];
  if (cat.sub && Object.keys(cat.sub).length > 0) {
    renderSubCatList(type);
  } else {
    renderScriptList(type, null, null);
  }
}

function renderSubCatList(type) {
  const cat = scripts[type];
  let buttonsHtml = '';
  Object.entries(cat.sub).forEach(([subKey, sub]) => {
    const color = sub.color || cat.color || '#3742fa';
    buttonsHtml += `<button onclick="selectSubCat('${type}','${subKey}')" style="background:${color}">${sub.name}</button>`;
  });
  contentArea.innerHTML = `
    <h2>${cat.name}</h2>
    <p style="font-size:12px;color:#888;margin:0 0 10px">カテゴリを選択してください</p>
    <div class="button-grid">${buttonsHtml}</div>
  `;
}

function selectSubCat(type, subKey) {
  historyStack.push(contentArea.innerHTML);
  forwardStack   = [];
  currentType    = type;
  currentSubKey  = subKey;
  currentOpenIndex = null;
  stepHistory    = [];
  renderScriptList(type, subKey, null);
}

// =====================================================
// スクリプト一覧
// =====================================================
function getScriptList(type, subKey) {
  const cat = scripts[type];
  if (subKey && cat.sub && cat.sub[subKey]) return cat.sub[subKey].list || [];
  return cat.list || [];
}

function renderScriptList(type, subKey, openIndex) {
  const cat   = scripts[type];
  const list  = getScriptList(type, subKey);
  const title = (subKey && cat.sub && cat.sub[subKey]) ? cat.sub[subKey].name : cat.name;

  let listHtml = '';
  list.forEach((item, i) => {
    const isActive = openIndex === i;
    listHtml += `
      <li class="script-list-item${isActive ? ' active' : ''}" onclick="toggleScriptItem('${type}','${subKey||''}',${i})">
        <span class="script-list-num">${String(i + 1).padStart(2, '0')}</span>
        <span class="script-list-title">${item.title}</span>
      </li>`;
  });

  let detailHtml;
  if (openIndex !== null) {
    visitedSteps = [];
    detailHtml = buildAllSteps(type, subKey, openIndex, 0);
  } else {
    detailHtml = `<div class="script-detail-empty">左のリストから項目を選択してください</div>`;
  }

  const panelClass = openIndex !== null ? 'script-panel has-selection' : 'script-panel';
  contentArea.innerHTML = `
    <h2>${title}</h2>
    <div class="${panelClass}">
      <ul class="script-list">${listHtml}</ul>
      <div class="script-detail" id="scriptDetail">${detailHtml}</div>
    </div>
  `;

  // サイドバー更新・フォーカス
  renderScriptSidebar();
}

// =====================================================
// ステップ縦並び描画エンジン
// =====================================================
function buildAllSteps(type, subKey, itemIndex, currentStepIndex) {
  const list = getScriptList(type, subKey);
  const item = list[itemIndex];
  if (!item) return '';

  let html = `<div class="script-detail-title">${item.title}</div>`;
  // 「現在位置へ」ボタン
  html += `<div class="scroll-to-current-wrap"><button class="scroll-to-current-btn" onclick="scrollToCurrent()">▼ 現在のステップへ</button></div>`;

  for (let si = 0; si <= currentStepIndex; si++) {
    const step    = item.steps[si];
    if (!step || !step.text) continue;
    const isCurrent = si === currentStepIndex;

    if (!isCurrent) {
      const chosen = visitedSteps.find(v =>
        v.type === type && v.subKey === subKey &&
        v.itemIndex === itemIndex && v.stepIndex === si
      );
      html += `<div class="step-bubble step-bubble-past">`;
      html += `<div class="step-bubble-num">ステップ ${si}</div>`;
      html += `<div class="step-bubble-text">${step.text}</div>`;
      if (chosen && chosen.choiceLabel) {
        html += `<div class="step-chosen-badge">✔ ${chosen.choiceLabel}</div>`;
      }
      html += `</div>`;
      if (si < currentStepIndex) {
        html += `<div class="step-connector">│</div>`;
      }
    } else {
      html += `<div class="step-bubble step-bubble-current" id="currentStepBubble">`;
      html += `<div class="step-bubble-num">ステップ ${si}${si === 0 ? ' ▶ 開始' : ''}</div>`;
      html += `<div class="step-bubble-text">${step.text}</div>`;
      if (step.memo) {
        html += `<div class="step-memo-display">📝 ${step.memo}</div>`;
      }
      // 選択肢
      if (step.choices && step.choices.length > 0) {
        html += `<div class="step-choices">`;
        step.choices.forEach(c => {
          if (typeof c.go === 'string' && c.go.includes('/')) {
            html += `<button class="step-choice-btn step-choice-jump" onclick="jumpToScript('${type}','${subKey||''}',${itemIndex},${si},'${c.go}','${(c.label||'').replace(/'/g,"\\'")}' )">${c.label} ↗</button>`;
          } else {
            html += `<button class="step-choice-btn" onclick="goStep('${type}','${subKey||''}',${itemIndex},${si},${c.go},'${(c.label||'').replace(/'/g,"\\'")}' )">${c.label}</button>`;
          }
        });
        html += `</div>`;
      } else {
        html += `<div class="step-end-badge">✓ 対応完了</div>`;
      }
      // 前のステップに戻るボタン（履歴がある場合）
      if (stepHistory.length > 0) {
        html += `<button class="step-back-btn" onclick="stepBack()">← 前のステップに戻る</button>`;
      }
      html += `</div>`;
    }
  }
  return html;
}

function scrollToCurrent() {
  const cur = document.getElementById('currentStepBubble');
  if (cur) cur.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function renderStepDetail(type, subKey, itemIndex, stepIndex) {
  const detail = document.getElementById('scriptDetail');
  if (!detail) return;
  detail.innerHTML = buildAllSteps(type, subKey, itemIndex, stepIndex);
  const cur = document.getElementById('currentStepBubble');
  if (cur) setTimeout(() => cur.scrollIntoView({ behavior: 'smooth', block: 'start' }), 50);
}

// =====================================================
// ステップ移動
// =====================================================
function goStep(type, subKey, itemIndex, fromIndex, nextIndex, choiceLabel) {
  stepHistory.push({ type, subKey, itemIndex, stepIndex: fromIndex });
  visitedSteps.push({ type, subKey, itemIndex, stepIndex: fromIndex, choiceLabel: choiceLabel||'' });
  renderStepDetail(type, subKey, itemIndex, nextIndex);
}

function jumpToScript(fromType, fromSubKey, fromItemIndex, fromStepIndex, goStr, choiceLabel) {
  const parts       = goStr.split('/');
  const toType      = parts[0];
  const toSubKey    = parts[1] || null;
  const toItemIndex = parseInt(parts[2]) || 0;
  const toStepIndex = parseInt(parts[3]) || 0;

  stepHistory.push({ type: fromType, subKey: fromSubKey, itemIndex: fromItemIndex, stepIndex: fromStepIndex, isScriptJump: true });
  visitedSteps.push({ type: fromType, subKey: fromSubKey, itemIndex: fromItemIndex, stepIndex: fromStepIndex, choiceLabel: choiceLabel||'', isScriptJump: true });

  currentType      = toType;
  currentSubKey    = toSubKey;
  currentOpenIndex = toItemIndex;
  renderScriptList(toType, toSubKey, toItemIndex);
  if (toStepIndex > 0) {
    renderStepDetail(toType, toSubKey, toItemIndex, toStepIndex);
  }
}

function stepBack() {
  if (stepHistory.length === 0) return;
  const prev = stepHistory.pop();
  visitedSteps = visitedSteps.filter(v =>
    !(v.type === prev.type && v.subKey === prev.subKey &&
      v.itemIndex === prev.itemIndex && v.stepIndex === prev.stepIndex)
  );
  if (prev.isScriptJump) {
    currentType      = prev.type;
    currentSubKey    = prev.subKey;
    currentOpenIndex = prev.itemIndex;
    renderScriptList(prev.type, prev.subKey, prev.itemIndex);
    renderStepDetail(prev.type, prev.subKey, prev.itemIndex, prev.stepIndex);
  } else {
    renderStepDetail(prev.type, prev.subKey, prev.itemIndex, prev.stepIndex);
  }
}

function toggleScriptItem(type, subKey, i) {
  currentType      = type;
  currentSubKey    = subKey || null;
  currentOpenIndex = i;
  stepHistory      = [];
  visitedSteps     = [];
  renderScriptList(type, subKey || null, i);
}

function openScript(type, subKey, i) {
  historyStack.push(contentArea.innerHTML);
  forwardStack     = [];
  currentType      = type;
  currentSubKey    = subKey || null;
  currentOpenIndex = i;
  stepHistory      = [];
  renderScriptList(type, subKey || null, i);
}

// =====================================================
// ナビゲーション
// =====================================================
function goBack() {
  if (historyStack.length > 0) {
    forwardStack.push(contentArea.innerHTML);
    contentArea.innerHTML = historyStack.pop();
  }
}

function goForward() {
  if (forwardStack.length > 0) {
    historyStack.push(contentArea.innerHTML);
    contentArea.innerHTML = forwardStack.pop();
  }
}

function goHome() {
  historyStack = []; forwardStack = [];
  currentType = null; currentSubKey = null; currentOpenIndex = null;
  stepHistory = []; visitedSteps = [];
  renderHome();
  renderScriptSidebar();
  closingText.innerHTML = "ご案内は以上となりますが、そのほか確認されたいことなどはございませんでしょうか？";
  searchBox.value = "";
  clearBtn.style.display = "none";
  suggestBox.style.display = "none";
  sideMenu.style.left = "-260px";
}

// =====================================================
// クロージング
// =====================================================
function closingNone() {
  closingText.innerHTML = "それでは本日●●がご案内いたしました。それでは失礼いたします。";
}
function closingAsk() {
  closingText.innerHTML = "追加質問に回答いたします。回答後、再度不明点確認を行います。";
}

// =====================================================
// 検索
// =====================================================
const searchBox = document.getElementById("searchBox");
const suggestBox = document.getElementById("suggestBox");
const clearBtn   = document.getElementById("clearBtn");

function getAllScripts() {
  const all = [];
  Object.entries(scripts).forEach(([typeKey, cat]) => {
    if (cat.sub) {
      Object.entries(cat.sub).forEach(([subKey, sub]) => {
        (sub.list || []).forEach((item, i) => {
          const fullText = item.steps ? item.steps.map(s => s.text || '').join(' ') : (item.text || '');
          all.push({ typeKey, subKey, index: i, categoryName: cat.name + ' › ' + sub.name, title: item.title, text: fullText });
        });
      });
    } else {
      (cat.list || []).forEach((item, i) => {
        const fullText = item.steps ? item.steps.map(s => s.text || '').join(' ') : (item.text || '');
        all.push({ typeKey, subKey: null, index: i, categoryName: cat.name, title: item.title, text: fullText });
      });
    }
  });
  return all;
}

function highlight(str, keyword) {
  if (!keyword) return str;
  const escaped = keyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return str.replace(new RegExp(escaped, 'gi'), match => `<mark>${match}</mark>`);
}

function excerpt(text, keyword) {
  const lower = text.toLowerCase(), kLower = keyword.toLowerCase();
  const idx = lower.indexOf(kLower);
  if (idx === -1) return "";
  const start = Math.max(0, idx - 30), end = Math.min(text.length, idx + keyword.length + 30);
  return (start > 0 ? "…" : "") + text.slice(start, end) + (end < text.length ? "…" : "");
}

searchBox.addEventListener("input", () => {
  const val = searchBox.value.trim();
  clearBtn.style.display = val ? "block" : "none";
  if (!val) { suggestBox.style.display = "none"; suggestBox.innerHTML = ""; return; }

  const allItems = getAllScripts();
  const results  = allItems.filter(item =>
    item.title.toLowerCase().includes(val.toLowerCase()) ||
    item.text.toLowerCase().includes(val.toLowerCase())
  );
  suggestBox.innerHTML = "";

  if (results.length === 0) {
    suggestBox.innerHTML = `<div class="no-result">「${val}」に一致するスクリプトが見つかりません</div>`;
    suggestBox.style.display = "block";
    return;
  }

  results.forEach(item => {
    const div = document.createElement("div");
    div.className = "suggest-item";
    const titleHtml = highlight(item.title, val);
    const textMatch = item.text.toLowerCase().includes(val.toLowerCase());
    div.innerHTML = `<div>${titleHtml}</div><div class="suggest-meta">${item.categoryName}</div>${textMatch ? `<div class="suggest-meta" style="margin-top:2px;">${excerpt(item.text, val)}</div>` : ""}`;
    div.onclick = () => { searchBox.value = item.title; suggestBox.style.display = "none"; showSearchResult(item, val); };
    suggestBox.appendChild(div);
  });
  suggestBox.style.display = "block";
});

function showSearchResult(item, keyword) {
  historyStack.push(contentArea.innerHTML);
  forwardStack = [];
  const titleHtml = highlight(item.title, keyword);
  const textHtml  = highlight(item.text, keyword);
  contentArea.innerHTML = `
    <h2>検索結果</h2>
    <div class="search-result-card" onclick="openScript('${item.typeKey}','${item.subKey||''}',${item.index})">
      <div class="result-title">${titleHtml}</div>
      <div class="result-category">${item.categoryName}</div>
      <div class="result-text">${textHtml}</div>
    </div>
  `;
}

clearBtn.onclick = () => {
  searchBox.value = "";
  clearBtn.style.display = "none";
  suggestBox.style.display = "none";
};

document.addEventListener("click", (e) => {
  if (!e.target.closest(".search-area")) suggestBox.style.display = "none";
});

// =====================================================
// JSONインポート
// =====================================================
// triggerImport / importJSON は sidemenu.js（共通）で定義済み

// toggleQuickMenu / copyText / クリック外閉じ は sidemenu.js（共通）で定義済み

// =====================================================
// 更新履歴
// =====================================================
function toggleHistory() {
  const body = document.getElementById("historyBody");
  body.style.display = body.style.display === "block" ? "none" : "block";
}

// =====================================================
// トークスクリプトサイドバー（サブカテゴリ対応・フォーカス）
// =====================================================
(function() {
  function renderScriptSidebar() {
    const el = document.getElementById('mailSidebarEl');
    if (!el) return;

    if (!scripts || !Object.keys(scripts).length) {
      el.innerHTML = '<div class="sb-acc-block"><div class="sb-acc-header"><span class="sb-acc-arrow">▶</span><span class="sb-acc-label">📂 すべて（0件）</span></div></div>';
      return;
    }

    let totalCount = 0;
    Object.values(scripts).forEach(cat => {
      if (cat.sub) {
        Object.values(cat.sub).forEach(sub => { totalCount += (sub.list || []).length; });
      } else {
        totalCount += (cat.list || []).length;
      }
    });

    let h = '';
    h += '<div class="sb-acc-block" id="sbAccAll">';
    h += '<div class="sb-acc-header" onclick="toggleSbAcc(\'sbAccAll\')" tabindex="0" role="button">';
    h += '<span class="sb-acc-arrow" style="transform:rotate(90deg)">▶</span>';
    h += '<span class="sb-acc-label">📂 すべて（' + totalCount + '件）</span>';
    h += '</div>';
    h += '<div class="sb-acc-body open">';

    Object.entries(scripts).forEach(function([key, cat]) {
      const color = cat.color || '#3742fa';
      h += '<div class="sb-acc-block" id="sbAcc_' + key + '">';
      h += '<div class="sb-acc-header sb-cat-header-inner" onclick="toggleSbAcc(\'sbAcc_' + key + '\')" tabindex="0" role="button">';
      h += '<span class="sb-acc-arrow" style="transform:rotate(90deg)">▶</span>';
      h += '<span class="sb-cat-dot" style="background:' + color + '"></span>';
      h += '<span class="sb-acc-label">' + (cat.name || '') + '</span>';
      h += '</div>';
      h += '<div class="sb-acc-body open">';

      if (cat.sub) {
        Object.entries(cat.sub).forEach(function([subKey, sub]) {
          h += '<div class="sb-acc-block" id="sbAcc_' + key + '_' + subKey + '">';
          h += '<div class="sb-acc-header sb-sub-header" onclick="toggleSbAcc(\'sbAcc_' + key + '_' + subKey + '\')" tabindex="0" role="button">';
          h += '<span class="sb-acc-arrow" style="transform:rotate(90deg)">▶</span>';
          h += '<span class="sb-acc-label">📁 ' + (sub.name || '') + '</span>';
          h += '</div>';
          h += '<div class="sb-acc-body open">';
          (sub.list || []).forEach(function(item, i) {
            const isActive = currentType === key && currentSubKey === subKey && currentOpenIndex === i;
            const itemId = 'sbItem_' + key + '_' + subKey + '_' + i;
            h += '<div class="sb-item' + (isActive ? ' active' : '') + '" id="' + itemId + '" onclick="selectUsageItem(\'' + key + '\',\'' + subKey + '\',' + i + ')" tabindex="0" role="button">';
            h += '<span class="sb-item-title">' + (item.title || '') + '</span>';
            h += '</div>';
          });
          h += '</div></div>';
        });
      } else {
        (cat.list || []).forEach(function(item, i) {
          const isActive = currentType === key && !currentSubKey && currentOpenIndex === i;
          const itemId = 'sbItem_' + key + '__' + i;
          h += '<div class="sb-item' + (isActive ? ' active' : '') + '" id="' + itemId + '" onclick="selectUsageItem(\'' + key + '\',\'\',' + i + ')" tabindex="0" role="button">';
          h += '<span class="sb-item-title">' + (item.title || '') + '</span>';
          h += '</div>';
        });
      }
      h += '</div></div>';
    });

    h += '</div></div>';
    el.innerHTML = h;

    // アクティブアイテムにスクロール（フォーカス）
    if (currentType !== null && currentOpenIndex !== null) {
      const subPart = currentSubKey || '';
      const activeEl = document.getElementById('sbItem_' + currentType + '_' + subPart + '_' + currentOpenIndex)
                    || document.getElementById('sbItem_' + currentType + '__' + currentOpenIndex);
      if (activeEl) {
        setTimeout(() => {
          activeEl.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
          activeEl.focus({ preventScroll: true });
        }, 80);
      }
    }
  }

  window.toggleSbAcc = function(id) {
    const block = document.getElementById(id);
    if (!block) return;
    const body  = block.querySelector(':scope > .sb-acc-body');
    const arrow = block.querySelector(':scope > .sb-acc-header .sb-acc-arrow');
    if (!body) return;
    const isOpen = body.classList.contains('open');
    body.classList.toggle('open', !isOpen);
    if (arrow) arrow.style.transform = isOpen ? '' : 'rotate(90deg)';
  };

  window.selectUsageItem = function(type, subKey, index) {
    historyStack.push(contentArea.innerHTML);
    forwardStack     = [];
    currentType      = type;
    currentSubKey    = subKey || null;
    currentOpenIndex = index;
    renderScriptList(type, subKey || null, index);
  };

  window.renderScriptSidebar = renderScriptSidebar;
  renderScriptSidebar();
})();

// =====================================================
// 別スクリプトジャンプ用スタイル
// =====================================================
(function() {
  const style = document.createElement('style');
  style.textContent = `
    .step-choice-jump { border-style: dashed !important; opacity: 0.85; }
    .scroll-to-current-wrap { display:flex; justify-content:flex-end; margin-bottom:4px; }
    .scroll-to-current-btn {
      font-size:11px; padding:4px 10px; border:1px solid #c5cee8;
      border-radius:20px; background:#f0f4ff; color:#4361ee;
      cursor:pointer; transition:background .15s;
    }
    .scroll-to-current-btn:hover { background:#e0e8ff; }
    .step-bubble-num { font-size:10px; font-weight:700; color:#888; margin-bottom:4px; }
    .step-bubble-text { white-space:pre-wrap; word-break:break-word; }
    .step-connector { text-align:center; color:#c0c8e0; font-size:18px; line-height:1.2; margin:2px 0; user-select:none; }
  `;
  document.head.appendChild(style);
})();

// =====================================================
// 初期化
// =====================================================
renderHome();
