// =====================================================
// 定型文リスト（ここを編集すれば全画面に反映）
// =====================================================
window.QUICK_ITEMS = [
  { text: '🟥HELP🟥',               label: '🟥HELP🟥'   },
  { text: '🟨保留中🟨',             label: '🟨保留中🟨' },
  { text: '🟦後処理🟦',             label: '🟦後処理🟦' },
  { text: '検証機お願いします（iPhone）',  label: 'iPhone'   },
  { text: '検証機お願いします（Android）', label: 'Android'  },
  { text: '休憩よろしいですか',      label: '10分休憩'   },
  { text: '食事よろしいですか',      label: 'お昼休憩'   },
  { text: '離席よろしいですか',      label: 'お手洗い'   },
];

// =====================================================
// 定型文メニューを動的生成（index.html / mail.html 共通）
// =====================================================
window.renderQuickMenu = function() {
  var el = document.getElementById('quickMenu');
  if (!el) return;
  // data属性で値を持たせてclickイベントで取得する（ダブルクォート崩れ対策）
  el.innerHTML = window.QUICK_ITEMS.map(function(item, i) {
    return '<div class="quick-menu-item" data-qi="' + i + '">' + item.label + '</div>';
  }).join('');
  el.addEventListener('click', function(ev) {
    var d = ev.target.closest('[data-qi]');
    if (!d) return;
    var item = window.QUICK_ITEMS[parseInt(d.dataset.qi)];
    if (item) window.copyText(item.text, item.label);
  });
};

// =====================================================
// 定型文クイックコピー（index.html / mail.html 共通）
// =====================================================
window.toggleQuickMenu = function() {
  var menu = document.getElementById('quickMenu');
  if (menu) menu.classList.toggle('open');
};

window.copyText = function(text, label) {
  function doToast() {
    var menu = document.getElementById('quickMenu');
    if (menu) menu.classList.remove('open');
    var toast = document.getElementById('quickCopyToast');
    if (!toast) return;
    toast.textContent = '「' + label + '」をコピーしました';
    toast.classList.add('show');
    setTimeout(function() { toast.classList.remove('show'); }, 2000);
  }
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(doToast).catch(function() {
      _fallbackCopy(text); doToast();
    });
  } else {
    _fallbackCopy(text); doToast();
  }
};

function _fallbackCopy(text) {
  var el = document.createElement('textarea');
  el.value = text;
  document.body.appendChild(el);
  el.select();
  document.execCommand('copy');
  document.body.removeChild(el);
}

// =====================================================
// データ更新（index.html / mail.html 共通）
// 統合JSON / スクリプト単体 / メール単体 すべてに対応
// =====================================================
window.triggerImport = function() {
  var el = document.getElementById('importFile');
  if (el) el.click();
};

window.importJSON = function(input) {
  var file = input.files[0];
  if (!file) return;
  var reader = new FileReader();
  reader.onload = function(e) {
    try {
      var raw = JSON.parse(e.target.result);

      // ── 統合JSON形式 {version:1, talkScripts, mailTemplates} ──
      if (raw && raw.version === 1 && raw.talkScripts && Array.isArray(raw.mailTemplates)) {
        if (!confirm('現在のデータをインポートしたデータで上書きします。よろしいですか？')) return;
        localStorage.setItem('talkScripts',   JSON.stringify(raw.talkScripts));
        localStorage.setItem('mailTemplates', JSON.stringify(raw.mailTemplates));
        location.reload();
        return;
      }

      // ── メールテンプレート単体（配列形式）──
      if (Array.isArray(raw)) {
        if (!confirm('現在のデータをインポートしたデータで上書きします。よろしいですか？')) return;
        localStorage.setItem('mailTemplates', JSON.stringify(raw));
        location.reload();
        return;
      }

      // ── トークスクリプト単体（オブジェクト形式）──
      var keys = Object.keys(raw);
      var valid = keys.length > 0 && keys.every(function(k) {
        return raw[k].name && (Array.isArray(raw[k].list) || raw[k].sub);
      });
      if (valid) {
        if (!confirm('現在のデータをインポートしたデータで上書きします。よろしいですか？')) return;
        localStorage.setItem('talkScripts', JSON.stringify(raw));
        location.reload();
        return;
      }

      alert('ファイルの形式が正しくありません');
    } catch(err) {
      alert('読み込みに失敗しました: ' + err.message);
    }
    input.value = '';
  };
  reader.readAsText(file);
};

// =====================================================
// 別タブ管理（既に開いていればフォーカス）
// =====================================================
var _namedTabs = {};
window.openNamedTab = function(url, name) {
  var tab = _namedTabs[name];
  if (tab && !tab.closed) { tab.focus(); }
  else { _namedTabs[name] = window.open(url, name); }
};

// =====================================================
// サイドメニュー開閉
// =====================================================
window.toggleSideMenu = function() {
  var m = document.getElementById('sideMenu');
  m.style.left = m.style.left === '0px' ? '-360px' : '0px';
};

// アコーディオン（第1階層）
window.toggleAccordion = function(id) {
  var body = document.getElementById(id);
  if (!body) return;
  var header = body.previousElementSibling;
  var isOpen = body.classList.contains('open');
  body.classList.toggle('open', !isOpen);
  if (header) header.classList.toggle('open', !isOpen);
};

// アコーディオン（第2階層）
window.toggleSubAccordion = function(id) {
  var body = document.getElementById(id);
  if (!body) return;
  var header = body.previousElementSibling;
  var isOpen = body.classList.contains('open');
  body.classList.toggle('open', !isOpen);
  if (header) header.classList.toggle('open', !isOpen);
};

// =====================================================
// DOM構築後にサイドメニューHTMLを挿入
// =====================================================
document.addEventListener('DOMContentLoaded', function() {
  window.renderQuickMenu();

  var m = document.getElementById('sideMenu');
  if (!m) return;

  function subAcc(id, label, items) {
    var lis = items.map(function(it) {
      return '<li><a href="' + (it.url || '#') + '" target="_blank">' + it.name + '</a></li>';
    }).join('');
    return '<li class="sub-acc-item">' +
      '<div class="sub-acc-header" onclick="toggleSubAccordion(\'' + id + '\')">' +
        '<span class="sub-arrow">▶</span>' + label +
      '</div>' +
      '<ul class="sub-acc-body" id="' + id + '">' + lis + '</ul>' +
    '</li>';
  }

  m.innerHTML =
    '<div class="side-section">' +
      '<div class="side-section-header" onclick="toggleAccordion(\'linkTools\')">🔧 ツール <span class="arrow">▶</span></div>' +
      '<ul class="accordion-body" id="linkTools">' +
        '<li><a href="#" target="_blank">Genesys</a></li>' +
        '<li><a href="#" target="_blank">CRM</a></li>' +
        '<li><a href="#" target="_blank">LINE WORKS</a></li>' +
        '<li><a href="#" target="_blank">対話要約AI</a></li>' +
      '</ul>' +
    '</div>' +
    '<div class="side-section">' +
      '<div class="side-section-header" onclick="toggleAccordion(\'linkDocs\')">📄 資料 <span class="arrow">▶</span></div>' +
      '<ul class="accordion-body" id="linkDocs">' +
        subAcc('subDocs_gyoumu', '業務資料', [
          { name: 'コンテンツ' }, { name: 'コンテンツ' }, { name: 'コンテンツ' }
        ]) +
        subAcc('subDocs_oubai', '応対品質', [
          { name: 'コンテンツ' }, { name: 'コンテンツ' }, { name: 'コンテンツ' }
        ]) +
      '</ul>' +
    '</div>' +
    '<div class="side-section">' +
      '<div class="side-section-header" onclick="toggleAccordion(\'linkSites\')">🌐 関連サイト <span class="arrow">▶</span></div>' +
      '<ul class="accordion-body" id="linkSites">' +
        '<li><a href="#" target="_blank">インフォメーション</a></li>' +
        '<li><a href="#" target="_blank">HP</a></li>' +
      '</ul>' +
    '</div>' +
    '<div class="side-section">' +
      '<div class="side-section-header" onclick="toggleAccordion(\'historyPanel\')">📝 更新履歴 <span class="arrow">▶</span></div>' +
      '<div class="accordion-body" id="historyPanel">' +
        '<table class="history-table">' +
          '<thead><tr><th>更新内容</th><th>更新者</th><th>承認者</th><th>更新日</th></tr></thead>' +
          '<tbody>' +
            '<tr><td>初版作成</td><td>菅原</td><td>-</td><td>2026/03/08</td></tr>' +
          '</tbody>' +
        '</table>' +
      '</div>' +
    '</div>';

  // クリック外でメニューを閉じる
  document.addEventListener('click', function(e) {
    // 定型文メニューを閉じる
    if (!e.target.closest('.quick-copy-area')) {
      var qm = document.getElementById('quickMenu');
      if (qm) qm.classList.remove('open');
    }
    // サイドメニューを閉じる
    var btn = document.getElementById('menuBtn');
    if (!m.contains(e.target) && e.target !== btn) {
      m.style.left = '-360px';
    }
  });
});

// =====================================================
// 管理画面 パスワード認証付きオープン
// =====================================================
var ADMIN_PW = 'admin1234';
var _adminUnlocked = false;

window.openAdminWithAuth = function() {
  if (_adminUnlocked) {
    window.openNamedTab('admin.html', 'adminTab');
    return;
  }
  var pw = prompt('管理画面のパスワードを入力してください');
  if (pw === null) return;
  if (pw === ADMIN_PW) {
    _adminUnlocked = true;
    window.openNamedTab('admin.html', 'adminTab');
  } else {
    alert('パスワードが違います');
  }
};
