// =====================================================
// スクリプトデータは管理画面（admin.html）で管理します
// =====================================================

// localStorageからデータを読み込む（管理画面で保存したJSONを使用）
let scripts;
try {
  const saved = localStorage.getItem('talkScripts');
  scripts = saved ? JSON.parse(saved) : {};
} catch(e) {
  scripts = {};
}

// =====================================================
// 以下はシステムコード（編集不要）
// =====================================================

let historyStack = [];
let forwardStack = [];

const contentArea = document.getElementById("contentArea");
const closingText = document.getElementById("closingText");

// ===== ホーム表示 =====
function renderHome() {
  let buttonsHtml = '';
  Object.entries(scripts).forEach(([key, cat]) => {
    const color = cat.color || '#3742fa';
    buttonsHtml += `<button onclick="selectUsage('${key}')" style="background:${color}">${cat.name}</button>`;
  });
  contentArea.innerHTML = `
    <h2>用途を選択してください</h2>
    <div class="button-grid">${buttonsHtml}</div>
  `;
}

// ===== 用途選択 =====
let currentType = null;
let currentSubKey = null;
let currentOpenIndex = null;
let stepHistory = []; // { type, itemIndex, stepIndex }

function selectUsage(type) {
  historyStack.push(contentArea.innerHTML);
  forwardStack = [];
  currentType = type;
  currentSubKey = null;
  currentOpenIndex = null;

  const cat = scripts[type];
  // サブカテゴリがある場合はサブカテゴリ選択画面へ
  if (cat.sub && Object.keys(cat.sub).length > 0) {
    renderSubCatList(type);
  } else {
    renderScriptList(type, null, null);
  }
}

// ===== サブカテゴリ選択画面 =====
function renderSubCatList(type) {
  const cat = scripts[type];
  let buttonsHtml = '';
  Object.entries(cat.sub).forEach(([subKey, sub]) => {
    const color = sub.color || cat.color || '#3742fa';
    buttonsHtml += `<button onclick="selectSubCat('${type}','${subKey}')" style="background:${color}">${sub.name}</button>`;
  });
  contentArea.innerHTML = `
    <h2>${cat.name}</h2>
    <p style="font-size:12px;color:#888;margin:0 0 10px">カテゴリを選択してください</p>
    <div class="button-grid">${buttonsHtml}</div>
  `;
}

function selectSubCat(type, subKey) {
  historyStack.push(contentArea.innerHTML);
  forwardStack = [];
  currentType = type;
  currentSubKey = subKey;
  currentOpenIndex = null;
  stepHistory = [];
  renderScriptList(type, subKey, null);
}

// ===== スクリプト一覧表示 =====
function getScriptList(type, subKey) {
  const cat = scripts[type];
  if (subKey && cat.sub && cat.sub[subKey]) return cat.sub[subKey].list || [];
  return cat.list || [];
}

function renderScriptList(type, subKey, openIndex) {
  const cat = scripts[type];
  const list = getScriptList(type, subKey);
  const title = (subKey && cat.sub && cat.sub[subKey]) ? cat.sub[subKey].name : cat.name;

  let listHtml = '';
  list.forEach((item, i) => {
    const isActive = openIndex === i;
    listHtml += `
      <li class="script-list-item${isActive ? ' active' : ''}" onclick="toggleScriptItem('${type}', '${subKey||''}', ${i})">
        <span class="script-list-num">${String(i + 1).padStart(2, '0')}</span>
        <span class="script-list-title">${item.title}</span>
      </li>`;
  });

  let detailHtml;
  if (openIndex !== null) {
    detailHtml = buildStepDetail(type, subKey, openIndex, 0);
  } else {
    detailHtml = `<div class="script-detail-empty">左のリストから項目を選択してください</div>`;
  }

  const panelClass = openIndex !== null ? 'script-panel has-selection' : 'script-panel';
  contentArea.innerHTML = `
    <h2>${title}</h2>
    <div class="${panelClass}">
      <ul class="script-list">${listHtml}</ul>
      <div class="script-detail" id="scriptDetail">${detailHtml}</div>
    </div>
  `;
}

// ===== ステップ描画エンジン =====
function buildStepDetail(type, subKey, itemIndex, stepIndex) {
  const list = getScriptList(type, subKey);
  const item = list[itemIndex];
  if (!item) return '';
  const step = item.steps[stepIndex];
  if (!step || !step.text) return '';

  const backBtn = stepHistory.length > 0
    ? `<button class="step-back-btn" onclick="stepBack()">← 前に戻る</button>`
    : '';

  let choicesHtml = '';
  if (step.choices && step.choices.length > 0) {
    choicesHtml = `<div class="step-choices">`;
    step.choices.forEach(c => {
      // go が "catKey/subKey/itemIndex/stepIndex" or "catKey//itemIndex/stepIndex" 形式 → 別スクリプトジャンプ
      if (typeof c.go === 'string' && c.go.includes('/')) {
        choicesHtml += `<button class="step-choice-btn step-choice-jump" onclick="jumpToScript('${type}','${subKey||''}',${itemIndex},${stepIndex},'${c.go}')">${c.label} ↗</button>`;
      } else {
        choicesHtml += `<button class="step-choice-btn" onclick="goStep('${type}','${subKey||''}',${itemIndex},${stepIndex},${c.go})">${c.label}</button>`;
      }
    });
    choicesHtml += `</div>`;
  } else {
    choicesHtml = `<div class="step-end-badge">✓ 対応完了</div>`;
  }

  return `
    <div class="script-detail-title">${item.title}</div>
    <div class="step-breadcrumb">${backBtn}</div>
    <div class="step-bubble">${step.text}</div>
    ${choicesHtml}
  `;
}

// ===== ステップ移動 =====
function goStep(type, subKey, itemIndex, fromIndex, nextIndex) {
  stepHistory.push({ type, subKey, itemIndex, stepIndex: fromIndex });
  const detail = document.getElementById('scriptDetail');
  if (detail) detail.innerHTML = buildStepDetail(type, subKey, itemIndex, nextIndex);
}

// ===== 別スクリプトへジャンプ =====
// go形式: "catKey/subKey/itemIndex/stepIndex"  subKeyなしの場合は空文字
function jumpToScript(fromType, fromSubKey, fromItemIndex, fromStepIndex, goStr) {
  const parts = goStr.split('/');
  const toType = parts[0];
  const toSubKey = parts[1] || null;
  const toItemIndex = parseInt(parts[2]) || 0;
  const toStepIndex = parseInt(parts[3]) || 0;

  // 現在位置を履歴に積む
  stepHistory.push({ type: fromType, subKey: fromSubKey, itemIndex: fromItemIndex, stepIndex: fromStepIndex, isScriptJump: true });

  // 別スクリプトの該当ステップを表示
  currentType = toType;
  currentSubKey = toSubKey;
  currentOpenIndex = toItemIndex;
  renderScriptList(toType, toSubKey, toItemIndex);
  // ステップが0以外の場合は指定ステップへ
  if (toStepIndex > 0) {
    const detail = document.getElementById('scriptDetail');
    if (detail) detail.innerHTML = buildStepDetail(toType, toSubKey, toItemIndex, toStepIndex);
  }
}

function stepBack() {
  if (stepHistory.length === 0) return;
  const prev = stepHistory.pop();
  if (prev.isScriptJump) {
    // 別スクリプトからの戻り → スクリプトリストごと戻す
    currentType = prev.type;
    currentSubKey = prev.subKey;
    currentOpenIndex = prev.itemIndex;
    renderScriptList(prev.type, prev.subKey, prev.itemIndex);
    const detail = document.getElementById('scriptDetail');
    if (detail) detail.innerHTML = buildStepDetail(prev.type, prev.subKey, prev.itemIndex, prev.stepIndex);
  } else {
    const detail = document.getElementById('scriptDetail');
    if (detail) detail.innerHTML = buildStepDetail(prev.type, prev.subKey, prev.itemIndex, prev.stepIndex);
  }
}

function toggleScriptItem(type, subKey, i) {
  currentType = type;
  currentSubKey = subKey || null;
  currentOpenIndex = i;
  stepHistory = [];
  renderScriptList(type, subKey || null, i);
}

// ===== スクリプト表示（検索用） =====
function openScript(type, subKey, i) {
  historyStack.push(contentArea.innerHTML);
  forwardStack = [];
  currentType = type;
  currentSubKey = subKey || null;
  currentOpenIndex = i;
  stepHistory = [];
  renderScriptList(type, subKey || null, i);
}

// ===== ナビゲーション =====
function goBack() {
  if (historyStack.length > 0) {
    forwardStack.push(contentArea.innerHTML);
    contentArea.innerHTML = historyStack.pop();
  }
}

function goForward() {
  if (forwardStack.length > 0) {
    historyStack.push(contentArea.innerHTML);
    contentArea.innerHTML = forwardStack.pop();
  }
}

function goHome() {
  historyStack = [];
  forwardStack = [];
  renderHome();
  closingText.innerHTML = "ご案内は以上となりますが、そのほか確認されたいことなどはございませんでしょうか？";
  searchBox.value = "";
  clearBtn.style.display = "none";
  suggestBox.style.display = "none";
  sideMenu.style.left = "-260px";
}

// ===== クロージング =====
function closingNone() {
  closingText.innerHTML = "それでは本日●●がご案内いたしました。それでは失礼いたします。";
}

function closingAsk() {
  closingText.innerHTML = "追加質問に回答いたします。回答後、再度不明点確認を行います。";
}

// ===== 検索（タイトル＋本文） =====
const searchBox = document.getElementById("searchBox");
const suggestBox = document.getElementById("suggestBox");
const clearBtn = document.getElementById("clearBtn");

function getAllScripts() {
  const all = [];
  Object.entries(scripts).forEach(([typeKey, cat]) => {
    // サブカテゴリあり
    if (cat.sub) {
      Object.entries(cat.sub).forEach(([subKey, sub]) => {
        (sub.list || []).forEach((item, i) => {
          const fullText = item.steps ? item.steps.map(s => s.text || '').join(' ') : (item.text || '');
          all.push({ typeKey, subKey, index: i, categoryName: cat.name + ' › ' + sub.name, title: item.title, text: fullText });
        });
      });
    } else {
      (cat.list || []).forEach((item, i) => {
        const fullText = item.steps ? item.steps.map(s => s.text || '').join(' ') : (item.text || '');
        all.push({ typeKey, subKey: null, index: i, categoryName: cat.name, title: item.title, text: fullText });
      });
    }
  });
  return all;
}

function highlight(str, keyword) {
  if (!keyword) return str;
  const escaped = keyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return str.replace(new RegExp(escaped, 'gi'), match => `<mark>${match}</mark>`);
}

function excerpt(text, keyword) {
  const lower = text.toLowerCase();
  const kLower = keyword.toLowerCase();
  const idx = lower.indexOf(kLower);
  if (idx === -1) return "";
  const start = Math.max(0, idx - 30);
  const end = Math.min(text.length, idx + keyword.length + 30);
  const snippet = (start > 0 ? "…" : "") + text.slice(start, end) + (end < text.length ? "…" : "");
  return highlight(snippet, keyword);
}

searchBox.addEventListener("input", () => {
  const val = searchBox.value.trim();
  clearBtn.style.display = val ? "block" : "none";

  if (!val) {
    suggestBox.style.display = "none";
    suggestBox.innerHTML = "";
    return;
  }

  const allItems = getAllScripts();
  const results = allItems.filter(item =>
    item.title.toLowerCase().includes(val.toLowerCase()) ||
    item.text.toLowerCase().includes(val.toLowerCase())
  );

  suggestBox.innerHTML = "";

  if (results.length === 0) {
    suggestBox.innerHTML = `<div class="no-result">「${val}」に一致するスクリプトが見つかりません</div>`;
    suggestBox.style.display = "block";
    return;
  }

  results.forEach(item => {
    const div = document.createElement("div");
    div.className = "suggest-item";
    const titleHtml = highlight(item.title, val);
    const textMatch = item.text.toLowerCase().includes(val.toLowerCase());
    div.innerHTML = `<div>${titleHtml}</div><div class="suggest-meta">${item.categoryName}</div>${textMatch ? `<div class="suggest-meta" style="margin-top:2px;">${excerpt(item.text, val)}</div>` : ""}`;
    div.onclick = () => {
      searchBox.value = item.title;
      suggestBox.style.display = "none";
      showSearchResult(item, val);
    };
    suggestBox.appendChild(div);
  });

  suggestBox.style.display = "block";
});

function showSearchResult(item, keyword) {
  historyStack.push(contentArea.innerHTML);
  forwardStack = [];
  const titleHtml = highlight(item.title, keyword);
  const textHtml = highlight(item.text, keyword);
  contentArea.innerHTML = `
    <h2>検索結果</h2>
    <div class="search-result-card" onclick="openScript('${item.typeKey}', '${item.subKey||''}', ${item.index})">
      <div class="result-title">${titleHtml}</div>
      <div class="result-category">${item.categoryName}</div>
      <div class="result-text">${textHtml}</div>
    </div>
  `;
}

clearBtn.onclick = () => {
  searchBox.value = "";
  clearBtn.style.display = "none";
  suggestBox.style.display = "none";
};

document.addEventListener("click", (e) => {
  if (!e.target.closest(".search-area")) {
    suggestBox.style.display = "none";
  }
});

// ===== JSONインポート（本番画面用） =====
function triggerImport() {
  document.getElementById('importFile').click();
}

function importJSON(input) {
  const file = input.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = function(e) {
    try {
      const raw = JSON.parse(e.target.result);
      let scriptsData = null;

      // 統合JSON形式（admin.htmlのエクスポート）
      if (raw.version === 1 && raw.talkScripts && raw.mailTemplates) {
        scriptsData = raw.talkScripts;
        if (Array.isArray(raw.mailTemplates)) {
          localStorage.setItem('mailTemplates', JSON.stringify(raw.mailTemplates));
        }
      }
      // 旧形式（スクリプトのみ）
      else {
        const keys = Object.keys(raw);
        const valid = keys.length > 0 && keys.every(k => raw[k].name && (Array.isArray(raw[k].list) || raw[k].sub));
        if (!valid) { alert('ファイルの形式が正しくありません'); return; }
        scriptsData = raw;
      }

      if (!confirm('現在のデータをインポートしたデータで上書きします。よろしいですか？')) return;
      localStorage.setItem('talkScripts', JSON.stringify(scriptsData));
      location.reload();
    } catch(err) {
      alert('読み込みに失敗しました: ' + err.message);
    }
    input.value = '';
  };
  reader.readAsText(file);
}

// ===== 定型文クイックコピー =====
function toggleQuickMenu() {
  const menu = document.getElementById('quickMenu');
  menu.classList.toggle('open');
}

function copyText(text, label) {
  navigator.clipboard.writeText(text).then(() => {
    document.getElementById('quickMenu').classList.remove('open');
    const toast = document.getElementById('quickCopyToast');
    toast.textContent = `「${label}」をコピーしました`;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 2000);
  }).catch(() => {
    const el = document.createElement('textarea');
    el.value = text;
    document.body.appendChild(el);
    el.select();
    document.execCommand('copy');
    document.body.removeChild(el);
    document.getElementById('quickMenu').classList.remove('open');
    const toast = document.getElementById('quickCopyToast');
    toast.textContent = `「${label}」をコピーしました`;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 2000);
  });
}

document.addEventListener('click', (e) => {
  if (!e.target.closest('.quick-copy-area')) {
    const menu = document.getElementById('quickMenu');
    if (menu) menu.classList.remove('open');
  }
});

// ===== 更新履歴 =====
function toggleHistory() {
  const body = document.getElementById("historyBody");
  body.style.display = body.style.display === "block" ? "none" : "block";
}

// ===== トークスクリプトサイドバー =====
(function() {
  function renderScriptSidebar() {
    const el = document.getElementById('mailSidebarEl');
    if (!el) return;

    if (!scripts || !Object.keys(scripts).length) {
      el.innerHTML = '<div class="sb-acc-block"><div class="sb-acc-header"><span class="sb-acc-arrow">▶</span><span class="sb-acc-label">📂 すべて（0件）</span></div></div>';
      return;
    }

    let totalCount = 0;
    Object.values(scripts).forEach(cat => {
      if (cat.sub) {
        Object.values(cat.sub).forEach(sub => { totalCount += (sub.list || []).length; });
      } else {
        totalCount += (cat.list || []).length;
      }
    });

    let h = '';
    h += '<div class="sb-acc-block" id="sbAccAll">';
    h += '<div class="sb-acc-header" onclick="toggleSbAcc(\'sbAccAll\')" tabindex="0" role="button">';
    h += '<span class="sb-acc-arrow">▶</span>';
    h += '<span class="sb-acc-label">📂 すべて（' + totalCount + '件）</span>';
    h += '</div>';
    h += '<div class="sb-acc-body">';

    Object.entries(scripts).forEach(function([key, cat]) {
      const color = cat.color || '#3742fa';
      h += '<div class="sb-acc-block" id="sbAcc_' + key + '">';
      h += '<div class="sb-acc-header sb-cat-header-inner" onclick="toggleSbAcc(\'sbAcc_' + key + '\')" tabindex="0" role="button">';
      h += '<span class="sb-acc-arrow">▶</span>';
      h += '<span class="sb-cat-dot" style="background:' + color + '"></span>';
      h += '<span class="sb-acc-label">' + (cat.name || '') + '</span>';
      h += '</div>';
      h += '<div class="sb-acc-body">';

      if (cat.sub) {
        // サブカテゴリあり
        Object.entries(cat.sub).forEach(function([subKey, sub]) {
          h += '<div class="sb-acc-block" id="sbAcc_' + key + '_' + subKey + '">';
          h += '<div class="sb-acc-header sb-cat-header-inner" onclick="toggleSbAcc(\'sbAcc_' + key + '_' + subKey + '\')" tabindex="0" role="button">';
          h += '<span class="sb-acc-arrow">▶</span>';
          h += '<span class="sb-acc-label">' + (sub.name || '') + '</span>';
          h += '</div>';
          h += '<div class="sb-acc-body">';
          (sub.list || []).forEach(function(item, i) {
            h += '<div class="sb-item" data-type="' + key + '" data-sub="' + subKey + '" data-index="' + i + '" onclick="selectUsageItem(\'' + key + '\',\'' + subKey + '\',' + i + ')" tabindex="0" role="button">';
            h += '<span class="sb-item-title">' + (item.title || '') + '</span>';
            h += '</div>';
          });
          h += '</div></div>';
        });
      } else {
        // サブカテゴリなし
        (cat.list || []).forEach(function(item, i) {
          h += '<div class="sb-item" data-type="' + key + '" data-index="' + i + '" onclick="selectUsageItem(\'' + key + '\',\'\',' + i + ')" tabindex="0" role="button">';
          h += '<span class="sb-item-title">' + (item.title || '') + '</span>';
          h += '</div>';
        });
      }

      h += '</div></div>';
    });

    h += '</div></div>';
    el.innerHTML = h;
  }

  window.toggleSbAcc = function(id) {
    const block = document.getElementById(id);
    if (!block) return;
    const body = block.querySelector(':scope > .sb-acc-body');
    const arrow = block.querySelector(':scope > .sb-acc-header .sb-acc-arrow');
    if (!body) return;
    const isOpen = body.classList.contains('open');
    body.classList.toggle('open', !isOpen);
    if (arrow) arrow.style.transform = isOpen ? '' : 'rotate(90deg)';
  };

  window.selectUsageItem = function(type, subKey, index) {
    historyStack.push(contentArea.innerHTML);
    forwardStack = [];
    currentType = type;
    currentSubKey = subKey || null;
    currentOpenIndex = index;
    renderScriptList(type, subKey || null, index);
  };

  renderScriptSidebar();
})();

// ===== 別スクリプトジャンプ用CSS追加 =====
(function() {
  const style = document.createElement('style');
  style.textContent = `.step-choice-jump { border-style: dashed !important; opacity: 0.85; }`;
  document.head.appendChild(style);
})();

// ===== 初期化 =====
renderHome();
