// ===== ヒアリング結果パネル =====
// sessionStorage で状態を永続化（タブを閉じるまで保持・リセットボタンでクリア）

var HEARING_KEY = 'hearingState_v2';

var DEFAULT_STATE = {
  usage: null,
  isMigration: null,
  oldPlusId: null,       // 2025/8/15時点で旧プラスのIDは発行されていたか
  migMailConfirmed: null, // 移行案内メールを確認しているか
  migMailUsable: null,   // 移行案内メールのアドレスが使用可能か
  isAccountPerson: null,
  sAccountCreated: null,
  jAccountCreated: null,
  sjLinked: null,        // '連携済み' | '未連携' | '再連携必要'
  devices: {},
  policy: null,          // 対応方針（自動設定）
  mailDomain: '',
  mailDomainManual: '',
  cbMistake: false,
  cbReject: false,
  cbSpam: false
};

var DEVICE_LIST = ['iPhone', 'Android', 'タブレット', 'PC', 'TV'];
var DEVICE_DETAIL_OPTIONS = {
  'iPhone':    ['Web', 'アプリ', 'Web,アプリ両方'],
  'Android':   ['Web', 'アプリ', 'Web,アプリ両方'],
  'タブレット': ['Web', 'アプリ', 'Web,アプリ両方'],
  'PC':        ['Windows', 'Mac', 'ChromeBook'],
  'TV':        []
};

// ===== 状態の読み込み・保存 =====
function loadHearingState() {
  try {
    var saved = sessionStorage.getItem(HEARING_KEY);
    if (saved) {
      var parsed = JSON.parse(saved);
      // devicesのデフォルトをマージ
      var devices = {};
      DEVICE_LIST.forEach(function(d) {
        devices[d] = (parsed.devices && parsed.devices[d]) ? parsed.devices[d] : { selected: false, detail: '' };
      });
      parsed.devices = devices;
      return Object.assign({}, DEFAULT_STATE, parsed);
    }
  } catch(e) {}
  var state = JSON.parse(JSON.stringify(DEFAULT_STATE));
  DEVICE_LIST.forEach(function(d) { state.devices[d] = { selected: false, detail: '' }; });
  return state;
}

function saveHearingState() {
  try { sessionStorage.setItem(HEARING_KEY, JSON.stringify(hearingState)); } catch(e) {}
}

// hearingState をセッションから初期化
var hearingState = loadHearingState();

// ===== パネル開閉 =====
var hearingPanelOpen = false;

window.toggleHearingPanel = function() {
  hearingPanelOpen = !hearingPanelOpen;
  var panel = document.getElementById('hearingPanel');
  var btn   = document.getElementById('hearingToggleBtn');
  if (panel) panel.classList.toggle('open', hearingPanelOpen);
  if (btn)   btn.textContent = hearingPanelOpen ? '＞' : '＜';
};

// ===== リセット =====
window.resetHearing = function() {
  hearingState = JSON.parse(JSON.stringify(DEFAULT_STATE));
  DEVICE_LIST.forEach(function(d) { hearingState.devices[d] = { selected: false, detail: '' }; });
  saveHearingState();
  renderHearing();
};

// ===== 値のセット（連鎖リセット付き） =====
window.setHearing = function(field, value) {
  if (field === 'usage') {
    hearingState.isMigration = null;
    hearingState.oldPlusId = null;
    hearingState.migMailConfirmed = null;
    hearingState.migMailUsable = null;
    hearingState.isAccountPerson = null;
    hearingState.sAccountCreated = null;
    hearingState.jAccountCreated = null;
    hearingState.sjLinked = null;
  }
  if (field === 'isMigration') {
    hearingState.oldPlusId = null;
    hearingState.migMailConfirmed = null;
    hearingState.migMailUsable = null;
    hearingState.sAccountCreated = null;
    hearingState.jAccountCreated = null;
    hearingState.sjLinked = null;
  }
  if (field === 'oldPlusId') {
    hearingState.migMailConfirmed = null;
    hearingState.migMailUsable = null;
  }
  if (field === 'migMailConfirmed') {
    hearingState.migMailUsable = null;
  }
  if (field === 'isAccountPerson') {
    hearingState.sAccountCreated = null;
    hearingState.jAccountCreated = null;
    hearingState.sjLinked = null;
  }
  if (field === 'sAccountCreated') {
    hearingState.jAccountCreated = null;
  }
  if (field === 'sjLinked') {
    // sjLinked は 3択文字列なのでそのまま
  }
  hearingState[field] = value;
  saveHearingState();
  renderHearing();
};

window.toggleHearingDevice = function(device) {
  var d = hearingState.devices[device];
  d.selected = !d.selected;
  if (!d.selected) d.detail = '';
  saveHearingState();
  renderHearing();
};

window.setHearingDeviceDetail = function(device, value) {
  hearingState.devices[device].detail = value;
  saveHearingState();
  renderHearing();
};

window.onHearingDomainChange = function() {
  var sel = document.getElementById('hearingDomainSel');
  if (!sel) return;
  hearingState.mailDomain = sel.value;
  var mw = document.getElementById('hearingDomainManualWrap');
  if (mw) mw.style.display = sel.value === '__manual__' ? 'block' : 'none';
  saveHearingState();
  renderHearingSummary();
};

window.onHearingDomainManualInput = function() {
  var inp = document.getElementById('hearingDomainManual');
  if (!inp) return;
  hearingState.mailDomainManual = inp.value;
  saveHearingState();
  renderHearingSummary();
};

window.onHearingCheckChange = function(field) {
  var el = document.getElementById('hearingCb_' + field);
  if (!el) return;
  hearingState[field] = el.checked;
  saveHearingState();
  renderHearingSummary();
};

// ===== ボタン生成ヘルパー =====
// value が boolean の場合: labels[0]=true, labels[1]=false
// value が文字列の場合: labelValues を参照
function boolBtns(field, value, labels) {
  return labels.map(function(lbl, i) {
    var v = (i === 0);
    var active = value === v ? ' active' : '';
    return '<button class="hr-btn' + active + '" onclick="setHearing(\'' + field + '\',' + v + ')">' + lbl + '</button>';
  }).join('');
}

function strBtns(field, value, labelValues) {
  // labelValues: [{label, value}, ...]
  return labelValues.map(function(item) {
    var active = value === item.value ? ' active' : '';
    return '<button class="hr-btn' + active + '" onclick="setHearing(\'' + field + '\',\'' + item.value + '\')">' + item.label + '</button>';
  }).join('');
}

// ===== 対応方針の自動導出 =====
function calcPolicy(s) {
  // 旧プラスID：いいえ → 新規登録案内
  if (s.usage === '世帯' && s.isMigration === true && s.oldPlusId === false) {
    return '移行対象者ではありませんので新規登録を案内してください';
  }
  // 移行案内メール未確認
  if (s.usage === '世帯' && s.isMigration === true && s.oldPlusId === true && s.migMailConfirmed === false) {
    return 'ガイダンス2で確認を依頼してください';
  }
  // 移行案内メールのアドレスが使用不可
  if (s.usage === '世帯' && s.isMigration === true && s.oldPlusId === true && s.migMailConfirmed === true && s.migMailUsable === false) {
    return 'ガイダンス2で連携解除を依頼してください';
  }
  // S-J連携：再連携が必要
  if (s.sjLinked === '再連携必要') {
    return 'ガイダンス2で連携解除後の再登録となることを案内してください';
  }
  return null;
}

// ===== メイン描画 =====
function renderHearing() {
  var el = document.getElementById('hearingContent');
  if (!el) return;
  var s = hearingState;
  var h = '';

  // ■用途
  h += row('用途',
    btn3('usage', s.usage, '世帯', '学校', '事業'));

  // ■移行対象者（世帯のみ）
  if (s.usage === '世帯') {
    h += row('移行対象者ですか？',
      boolBtns('isMigration', s.isMigration, ['はい', 'いいえ']));
  }

  // ■旧プラスID（移行対象者:はい のみ）
  if (s.usage === '世帯' && s.isMigration === true) {
    h += row('2025/8/15時点で旧プラスのIDは発行されていましたか？',
      boolBtns('oldPlusId', s.oldPlusId, ['はい(わからない)', 'いいえ']));
  }

  // ■移行案内メール確認（旧プラスID:はい のみ）
  if (s.usage === '世帯' && s.isMigration === true && s.oldPlusId === true) {
    h += row('7月/9月/10月に送信している移行案内メールは確認されていますか？',
      boolBtns('migMailConfirmed', s.migMailConfirmed, ['はい', 'いいえ(わからない)']));
  }

  // ■移行案内メールアドレス使用可能（確認:はい のみ）
  if (s.usage === '世帯' && s.isMigration === true && s.oldPlusId === true && s.migMailConfirmed === true) {
    h += row('移行案内メールを受信しているメールアドレスは現在も使用可能ですか？',
      boolBtns('migMailUsable', s.migMailUsable, ['はい', 'いいえ']));
  }

  // ■アカウント担当者（学校・事業のみ）
  if (s.usage === '学校' || s.usage === '事業') {
    h += row('入電者はアカウント担当者ですか？',
      boolBtns('isAccountPerson', s.isAccountPerson, ['はい', 'いいえ']));
  }

  // ■Sアカ（用途選択後）
  if (s.usage !== null) {
    h += row('Sアカは作成済みですか？',
      boolBtns('sAccountCreated', s.sAccountCreated, ['はい', 'いいえ']));
  }

  // ■Jアカ（世帯 && Sアカ:はい）
  if (s.usage === '世帯' && s.sAccountCreated === true) {
    h += row('Jアカは作成済みですか？',
      boolBtns('jAccountCreated', s.jAccountCreated, ['はい', 'いいえ']));
  }

  // ■S-J連携（世帯のみ・3択）
  if (s.usage === '世帯') {
    h += row('S-J連携済みですか？',
      strBtns('sjLinked', s.sjLinked, [
        { label: '連携済み',   value: '連携済み' },
        { label: '未連携',     value: '未連携' },
        { label: '未確認（再連携が必要です）', value: '再連携必要' }
      ]));
  }

  // ■操作環境
  var devBtns = '<div class="hr-device-btns">';
  DEVICE_LIST.forEach(function(device) {
    var d = s.devices[device];
    devBtns += '<button class="hr-device-btn' + (d.selected ? ' active' : '') + '" onclick="toggleHearingDevice(\'' + device + '\')">' + device + '</button>';
  });
  devBtns += '</div>';
  DEVICE_LIST.forEach(function(device) {
    var d = s.devices[device];
    var opts = DEVICE_DETAIL_OPTIONS[device];
    if (d.selected && opts && opts.length > 0) {
      devBtns += '<div class="hr-device-detail"><span class="hr-device-detail-label">' + device + '：</span>';
      opts.forEach(function(opt) {
        devBtns += '<button class="hr-detail-btn' + (d.detail === opt ? ' active' : '') + '" onclick="setHearingDeviceDetail(\'' + device + '\',\'' + opt + '\')">' + opt + '</button>';
      });
      devBtns += '</div>';
    }
  });
  h += row('操作環境', devBtns, 'hr-row-devices');

  // ---- メール未着調査 ----
  h += '<div class="hr-divider">メール未着調査</div>';

  var dv = s.mailDomain;
  h += '<div class="hr-row">'
     + '<div class="hr-label">■ドメイン（＠以降）</div>'
     + '<select id="hearingDomainSel" class="hr-select" onchange="onHearingDomainChange()">'
     + '<option value="">選択してください</option>'
     + opt('@gmail.com',   dv) + opt('@yahoo.co.jp', dv) + opt('@outlook.com', dv)
     + '<option value="__manual__"' + (dv === '__manual__' ? ' selected' : '') + '>その他（手入力）</option>'
     + '</select>'
     + '<div id="hearingDomainManualWrap" style="display:' + (dv === '__manual__' ? 'block' : 'none') + ';margin-top:6px;">'
     + '<input id="hearingDomainManual" type="text" class="hr-text-input" placeholder="例）@example.com" value="' + esc(s.mailDomainManual) + '" oninput="onHearingDomainManualInput()">'
     + '</div></div>';

  h += '<div class="hr-row">'
     + '<div class="hr-label">■確認項目</div>'
     + chk('cbMistake', s.cbMistake, 'メールアドレスの入力ミス')
     + chk('cbReject',  s.cbReject,  '受信拒否')
     + chk('cbSpam',    s.cbSpam,    '迷惑メールフィルター')
     + '</div>';

  // サマリーエリア
  h += '<div id="hearingSummaryArea"></div>';

  el.innerHTML = h;
  renderHearingSummary();
}

// ===== 小ヘルパー =====
function row(label, content, extraClass) {
  return '<div class="hr-row' + (extraClass ? ' ' + extraClass : '') + '">'
       + '<div class="hr-label">■' + label + '</div>'
       + '<div class="hr-btns">' + content + '</div>'
       + '</div>';
}
function btn3(field, val, a, b, c) {
  return [a, b, c].map(function(v) {
    return '<button class="hr-btn' + (val === v ? ' active' : '') + '" onclick="setHearing(\'' + field + '\',\'' + v + '\')">' + v + '</button>';
  }).join('');
}
function opt(val, selected) {
  return '<option value="' + val + '"' + (selected === val ? ' selected' : '') + '>' + val + '</option>';
}
function chk(id, checked, label) {
  return '<label class="hr-check-label">'
       + '<input id="hearingCb_' + id + '" type="checkbox" ' + (checked ? 'checked' : '') + ' onchange="onHearingCheckChange(\'' + id + '\')">'
       + ' ' + label + '</label>';
}
function esc(s) {
  return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ===== サマリー描画 =====
function renderHearingSummary() {
  var area = document.getElementById('hearingSummaryArea');
  if (!area) return;
  var s = hearingState;
  var rows = [];

  if (s.usage) rows.push(['用途', s.usage]);

  if (s.usage === '世帯') {
    if (s.isMigration !== null)
      rows.push(['移行対象者', s.isMigration ? 'はい' : 'いいえ']);

    if (s.isMigration === true) {
      if (s.oldPlusId !== null)
        rows.push(['旧プラスID発行', s.oldPlusId ? 'はい(わからない)' : 'いいえ']);
      if (s.oldPlusId === true) {
        if (s.migMailConfirmed !== null)
          rows.push(['移行案内メール確認', s.migMailConfirmed ? 'はい' : 'いいえ(わからない)']);
        if (s.migMailConfirmed === true && s.migMailUsable !== null)
          rows.push(['メールアドレス使用可', s.migMailUsable ? 'はい' : 'いいえ']);
      }
    }
  }

  if ((s.usage === '学校' || s.usage === '事業') && s.isAccountPerson !== null)
    rows.push(['アカウント担当者', s.isAccountPerson ? 'はい' : 'いいえ']);

  if (s.sAccountCreated !== null)
    rows.push(['Sアカ作成済み', s.sAccountCreated ? 'はい' : 'いいえ']);
  if (s.usage === '世帯' && s.jAccountCreated !== null)
    rows.push(['Jアカ作成済み', s.jAccountCreated ? 'はい' : 'いいえ']);
  if (s.usage === '世帯' && s.sjLinked !== null)
    rows.push(['S-J連携', s.sjLinked === '再連携必要' ? '未確認（再連携必要）' : s.sjLinked]);

  // 操作環境
  var envParts = [];
  DEVICE_LIST.forEach(function(device) {
    var d = s.devices[device];
    if (d.selected) envParts.push(d.detail ? device + '(' + d.detail + ')' : device);
  });
  if (envParts.length) rows.push(['操作環境', envParts.join('、')]);

  // メール未着
  var domain = s.mailDomain === '__manual__' ? s.mailDomainManual : s.mailDomain;
  if (domain) rows.push(['ドメイン', domain]);
  var checks = [];
  if (s.cbMistake) checks.push('入力ミス');
  if (s.cbReject)  checks.push('受信拒否');
  if (s.cbSpam)    checks.push('迷惑メールフィルター');
  if (checks.length) rows.push(['確認項目', checks.join('、')]);

  // 対応方針
  var policy = calcPolicy(s);
  if (policy) rows.push(['__policy__', policy]);

  if (rows.length === 0) { area.innerHTML = ''; return; }

  var h = '<div class="hr-summary"><div class="hr-summary-title">📋 ヒアリング内容</div><div class="hr-summary-rows">';
  rows.forEach(function(r) {
    var label = r[0], val = r[1];
    if (label === '__policy__') {
      h += '<div class="hr-summary-policy"><span class="hr-policy-icon">📌</span><span class="hr-policy-text">対応方針：' + esc(val) + '</span></div>';
      return;
    }
    var valClass = 'hr-sum-val';
    if (val === 'はい' || val === 'はい(わからない)' || val === '連携済み') valClass += ' hr-sum-yes';
    if (val === 'いいえ' || val === 'いいえ(わからない)' || val === '未連携' || val === '未確認（再連携必要）') valClass += ' hr-sum-no';
    h += '<div class="hr-summary-row"><span class="hr-sum-label">' + esc(label) + '</span><span class="' + valClass + '">' + esc(val) + '</span></div>';
  });
  h += '</div></div>';
  area.innerHTML = h;
}

// ===== ヒアリング内容をテキストコピー =====
window.copyHearingText = function() {
  var s = hearingState;
  var lines = [];

  if (s.usage) lines.push('用途：' + s.usage);
  if (s.usage === '世帯') {
    if (s.isMigration !== null)
      lines.push('移行対象者：' + (s.isMigration ? 'はい' : 'いいえ'));
    if (s.isMigration === true) {
      if (s.oldPlusId !== null)
        lines.push('旧プラスID発行：' + (s.oldPlusId ? 'はい(わからない)' : 'いいえ'));
      if (s.oldPlusId === true) {
        if (s.migMailConfirmed !== null)
          lines.push('移行案内メール確認：' + (s.migMailConfirmed ? 'はい' : 'いいえ(わからない)'));
        if (s.migMailConfirmed === true && s.migMailUsable !== null)
          lines.push('メールアドレス使用可：' + (s.migMailUsable ? 'はい' : 'いいえ'));
      }
    }
  }
  if ((s.usage === '学校' || s.usage === '事業') && s.isAccountPerson !== null)
    lines.push('アカウント担当者：' + (s.isAccountPerson ? 'はい' : 'いいえ'));
  if (s.sAccountCreated !== null)
    lines.push('Sアカ作成済み：' + (s.sAccountCreated ? 'はい' : 'いいえ'));
  if (s.usage === '世帯' && s.jAccountCreated !== null)
    lines.push('Jアカ作成済み：' + (s.jAccountCreated ? 'はい' : 'いいえ'));
  if (s.usage === '世帯' && s.sjLinked !== null)
    lines.push('S-J連携：' + (s.sjLinked === '再連携必要' ? '未確認（再連携必要）' : s.sjLinked));

  var envParts = [];
  DEVICE_LIST.forEach(function(device) {
    var d = s.devices[device];
    if (d.selected) envParts.push(d.detail ? device + '(' + d.detail + ')' : device);
  });
  if (envParts.length) lines.push('操作環境：' + envParts.join('、'));

  var domain = s.mailDomain === '__manual__' ? s.mailDomainManual : s.mailDomain;
  if (domain) lines.push('ドメイン：' + domain);
  var checks = [];
  if (s.cbMistake) checks.push('入力ミス');
  if (s.cbReject)  checks.push('受信拒否');
  if (s.cbSpam)    checks.push('迷惑メールフィルター');
  if (checks.length) lines.push('確認項目：' + checks.join('、'));

  var policy = calcPolicy(s);
  if (policy) lines.push('対応方針：' + policy);

  if (lines.length === 0) {
    showHearingCopyToast('コピーする内容がありません', true);
    return;
  }

  var text = lines.join('\n');
  var done = function() { showHearingCopyToast('ヒアリング内容をコピーしました', false); };
  if (navigator.clipboard) {
    navigator.clipboard.writeText(text).then(done).catch(function() { fallbackCopyH(text); done(); });
  } else { fallbackCopyH(text); done(); }
};

function fallbackCopyH(text) {
  var el = document.createElement('textarea');
  el.value = text;
  document.body.appendChild(el);
  el.select();
  document.execCommand('copy');
  document.body.removeChild(el);
}

function showHearingCopyToast(msg, isError) {
  var toast = document.getElementById('hearingCopyToast');
  if (!toast) return;
  toast.textContent = msg;
  toast.className = 'hearing-copy-toast show' + (isError ? ' error' : '');
  clearTimeout(toast._t);
  toast._t = setTimeout(function() { toast.className = 'hearing-copy-toast'; }, 2000);
}

document.addEventListener('DOMContentLoaded', renderHearing);
