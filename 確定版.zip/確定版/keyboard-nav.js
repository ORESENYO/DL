// ===== キーボードナビゲーション =====
// ←→↑↓ Enter Tab での操作を全画面で有効化

document.addEventListener('keydown', function(e) {
  const key = e.key;

  // Tab/Shift+Tab: フォーカス移動（デフォルト動作 + tabindex付き要素を優先）
  // ↑↓ でリスト内移動、←→でステップ分岐・戻る
  // Enter でクリック実行

  // フォーカス中の要素
  const focused = document.activeElement;

  // --- Enter: フォーカス中ボタン/クリック可能要素を押す ---
  if (key === 'Enter') {
    if (focused && focused !== document.body) {
      if (focused.tagName === 'BUTTON' || focused.getAttribute('role') === 'button' || focused.classList.contains('sb-item') || focused.classList.contains('script-list-item') || focused.classList.contains('step-choice-btn') || focused.classList.contains('suggest-item')) {
        focused.click();
        e.preventDefault();
        return;
      }
    }
  }

  // --- 検索ボックスにフォーカスがある場合のサジェスト操作 ---
  const searchBox = document.getElementById('searchBox');
  const suggestBox = document.getElementById('suggestBox');
  if (focused === searchBox && suggestBox && suggestBox.style.display !== 'none') {
    const items = suggestBox.querySelectorAll('.suggest-item');
    if (items.length === 0) return;
    const current = suggestBox.querySelector('.suggest-item.kb-focus');
    let idx = -1;
    items.forEach((el, i) => { if (el === current) idx = i; });

    if (key === 'ArrowDown') {
      e.preventDefault();
      if (current) current.classList.remove('kb-focus');
      const next = items[Math.min(idx + 1, items.length - 1)];
      next.classList.add('kb-focus');
      next.scrollIntoView({ block: 'nearest' });
      return;
    }
    if (key === 'ArrowUp') {
      e.preventDefault();
      if (current) current.classList.remove('kb-focus');
      if (idx > 0) {
        const prev = items[idx - 1];
        prev.classList.add('kb-focus');
        prev.scrollIntoView({ block: 'nearest' });
      }
      return;
    }
    if (key === 'Enter') {
      e.preventDefault();
      if (current) { current.click(); return; }
      if (items.length > 0) { items[0].click(); return; }
    }
  }

  // --- スクリプトリスト（左ペイン）矢印キー操作 ---
  const scriptList = document.querySelector('.script-list');
  if (scriptList) {
    const items = Array.from(scriptList.querySelectorAll('.script-list-item'));
    if (items.length === 0) return; // リストなければスキップ
    const activeItem = scriptList.querySelector('.script-list-item.active');
    let idx = items.indexOf(activeItem);

    if (key === 'ArrowDown') {
      e.preventDefault();
      const next = items[Math.min(idx + 1, items.length - 1)];
      if (next) { next.click(); next.focus(); }
      return;
    }
    if (key === 'ArrowUp') {
      e.preventDefault();
      const prev = items[Math.max(idx - 1, 0)];
      if (prev) { prev.click(); prev.focus(); }
      return;
    }
  }

  // --- ステップ分岐ボタン操作（Enter/矢印） ---
  const stepChoices = document.querySelectorAll('.step-choice-btn');
  if (stepChoices.length > 0 && (key === 'ArrowDown' || key === 'ArrowUp' || key === 'ArrowRight' || key === 'ArrowLeft')) {
    const arr = Array.from(stepChoices);
    const focusedIdx = arr.indexOf(document.activeElement);
    if (focusedIdx === -1) {
      // フォーカスなければ最初に当てる
      if (key === 'ArrowDown' || key === 'ArrowRight') {
        arr[0].focus();
        e.preventDefault();
      }
      return;
    }
    if (key === 'ArrowDown' || key === 'ArrowRight') {
      e.preventDefault();
      arr[Math.min(focusedIdx + 1, arr.length - 1)].focus();
      return;
    }
    if (key === 'ArrowUp' || key === 'ArrowLeft') {
      e.preventDefault();
      if (focusedIdx > 0) arr[focusedIdx - 1].focus();
      return;
    }
  }

  // --- ← キー: 戻る ---
  if (key === 'ArrowLeft') {
    // テキスト入力中は無視
    if (focused && (focused.tagName === 'INPUT' || focused.tagName === 'TEXTAREA' || focused.tagName === 'SELECT')) return;
    // ステップ戻る
    const backBtn = document.querySelector('.step-back-btn');
    if (backBtn) { e.preventDefault(); backBtn.click(); return; }
    // ページ戻る
    if (typeof goBack === 'function') { e.preventDefault(); goBack(); }
    return;
  }

  // --- → キー: 進む ---
  if (key === 'ArrowRight') {
    if (focused && (focused.tagName === 'INPUT' || focused.tagName === 'TEXTAREA' || focused.tagName === 'SELECT')) return;
    if (typeof goForward === 'function') { e.preventDefault(); goForward(); }
    return;
  }

  // --- サイドバーアコーディオンの矢印キー ---
  if (focused && focused.closest('.sb-acc-header')) {
    const block = focused.closest('.sb-acc-block');
    if (key === 'ArrowRight' || key === 'Enter') {
      e.preventDefault();
      const body = block && block.querySelector(':scope > .sb-acc-body');
      if (body && !body.classList.contains('open')) focused.click();
      return;
    }
    if (key === 'ArrowLeft') {
      e.preventDefault();
      const body = block && block.querySelector(':scope > .sb-acc-body');
      if (body && body.classList.contains('open')) focused.click();
      return;
    }
    if (key === 'ArrowDown') {
      e.preventDefault();
      // 次のfocusable要素
      const allFocusable = Array.from(document.querySelectorAll('#mailSidebarEl [tabindex="0"]'));
      const idx = allFocusable.indexOf(focused);
      if (idx < allFocusable.length - 1) allFocusable[idx + 1].focus();
      return;
    }
    if (key === 'ArrowUp') {
      e.preventDefault();
      const allFocusable = Array.from(document.querySelectorAll('#mailSidebarEl [tabindex="0"]'));
      const idx = allFocusable.indexOf(focused);
      if (idx > 0) allFocusable[idx - 1].focus();
      return;
    }
  }

  // --- サイドバーアイテム矢印キー ---
  if (focused && focused.classList.contains('sb-item')) {
    if (key === 'ArrowDown') {
      e.preventDefault();
      const allFocusable = Array.from(document.querySelectorAll('#mailSidebarEl [tabindex="0"]'));
      const idx = allFocusable.indexOf(focused);
      if (idx < allFocusable.length - 1) allFocusable[idx + 1].focus();
      return;
    }
    if (key === 'ArrowUp') {
      e.preventDefault();
      const allFocusable = Array.from(document.querySelectorAll('#mailSidebarEl [tabindex="0"]'));
      const idx = allFocusable.indexOf(focused);
      if (idx > 0) allFocusable[idx - 1].focus();
      return;
    }
  }

  // --- ホームボタングリッド矢印キー ---
  const buttonGrid = document.querySelector('.button-grid');
  if (buttonGrid && focused && buttonGrid.contains(focused)) {
    const btns = Array.from(buttonGrid.querySelectorAll('button'));
    const idx = btns.indexOf(focused);
    if (key === 'ArrowRight' || key === 'ArrowDown') {
      e.preventDefault();
      btns[Math.min(idx + 1, btns.length - 1)].focus();
      return;
    }
    if (key === 'ArrowLeft' || key === 'ArrowUp') {
      e.preventDefault();
      btns[Math.max(idx - 1, 0)].focus();
      return;
    }
  }
});

// サジェストアイテムのkb-focusスタイル用CSS動的追加
(function() {
  const style = document.createElement('style');
  style.textContent = `
    .suggest-item.kb-focus { background: #eef0ff !important; }
    .script-list-item:focus { outline: 2px solid #3742fa; outline-offset: -2px; }
    .step-choice-btn:focus { outline: 2px solid #3742fa; border-color: #3742fa; background: #f0f4ff; }
    .sb-acc-header:focus { outline: 2px solid #3742fa; outline-offset: -2px; }
    .sb-item:focus { outline: 2px solid #3742fa; outline-offset: -2px; }
    .hr-btn:focus, .hr-device-btn:focus, .hr-detail-btn:focus { outline: 2px solid #3742fa; }
  `;
  document.head.appendChild(style);
})();
