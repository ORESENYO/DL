// Dark mode init (runs before DOM builds - prevents flash)
(function(){var s=localStorage.getItem('darkMode');if(s==='1')document.documentElement.setAttribute('data-theme','dark');else if(s==='0')document.documentElement.setAttribute('data-theme','light');})();

window.applyDarkMode=function(d){if(d){document.documentElement.setAttribute('data-theme','dark');localStorage.setItem('darkMode','1');}else{document.documentElement.setAttribute('data-theme','light');localStorage.setItem('darkMode','0');}var c=document.getElementById('darkModeToggle');if(c)c.checked=d;};

window.QUICK_ITEMS=[
  {text:'🟥HELP🟥',label:'🟥HELP🟥'},{text:'🟨保留中🟨',label:'🟨保留中🟨'},
  {text:'🟦後処理🟦',label:'🟦後処理🟦'},{text:'📱【検証機使用希望】📱（iPhone）',label:'iPhone'},
  {text:'📱【検証機使用希望】📱（Android）',label:'Android'},{text:'☕10分休憩よろしいでしょうか☕',label:'10分休憩'},
  {text:'🍱お昼休憩よろしいでしょうか🍱',label:'お昼休憩'},{text:'🐻離席してもよろしいでしょうか🐻',label:'お手洗い'},
];

window.renderQuickMenu=function(){var el=document.getElementById('quickMenu');if(!el)return;el.innerHTML=window.QUICK_ITEMS.map(function(item,i){return'<div class="quick-menu-item" data-qi="'+i+'">'+item.label+'</div>';}).join('');el.addEventListener('click',function(ev){var d=ev.target.closest('[data-qi]');if(!d)return;var item=window.QUICK_ITEMS[parseInt(d.dataset.qi)];if(item)window.copyText(item.text,item.label);});};
window.toggleQuickMenu=function(){var menu=document.getElementById('quickMenu');if(menu)menu.classList.toggle('open');};
window.copyText=function(text,label){function doToast(){var menu=document.getElementById('quickMenu');if(menu)menu.classList.remove('open');var toast=document.getElementById('quickCopyToast');if(!toast)return;toast.textContent='「'+label+'」をコピーしました';toast.classList.add('show');setTimeout(function(){toast.classList.remove('show');},2000);}if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(text).then(doToast).catch(function(){_fallbackCopy(text);doToast();});}else{_fallbackCopy(text);doToast();}};
function _fallbackCopy(text){var el=document.createElement('textarea');el.value=text;document.body.appendChild(el);el.select();document.execCommand('copy');document.body.removeChild(el);}

window.triggerImport=function(){var el=document.getElementById('importFile');if(el)el.click();};
window.importJSON=function(input){var file=input.files[0];if(!file)return;var reader=new FileReader();reader.onload=function(e){_processImportText(e.target.result);input.value='';};reader.readAsText(file);};
function _processImportText(text){try{var raw=JSON.parse(text);if(raw&&raw.version===1&&raw.talkScripts&&Array.isArray(raw.mailTemplates)){if(!confirm('現在のデータをインポートしたデータで上書きします。よろしいですか？'))return;localStorage.setItem('talkScripts',JSON.stringify(raw.talkScripts));localStorage.setItem('mailTemplates',JSON.stringify(raw.mailTemplates));location.reload();return;}if(Array.isArray(raw)){if(!confirm('現在のデータをインポートしたデータで上書きします。よろしいですか？'))return;localStorage.setItem('mailTemplates',JSON.stringify(raw));location.reload();return;}var keys=Object.keys(raw);var valid=keys.length>0&&keys.every(function(k){return raw[k].name&&(Array.isArray(raw[k].list)||raw[k].sub);});if(valid){if(!confirm('現在のデータをインポートしたデータで上書きします。よろしいですか？'))return;localStorage.setItem('talkScripts',JSON.stringify(raw));location.reload();return;}alert('ファイルの形式が正しくありません。');}catch(err){alert('読み込みに失敗しました: '+err.message);}}

var _namedTabs={};
window.openNamedTab=function(url,name){var tab=_namedTabs[name];if(tab&&!tab.closed){tab.focus();}else{_namedTabs[name]=window.open(url,name);}};
window.toggleSideMenu=function(){var m=document.getElementById('sideMenu');if(!m)return;m.classList.toggle('open');};
window.toggleAccordion=function(id){var body=document.getElementById(id);if(!body)return;var header=body.previousElementSibling;var isOpen=body.classList.contains('open');body.classList.toggle('open',!isOpen);if(header)header.classList.toggle('open',!isOpen);};
window.toggleSubAccordion=function(id){var body=document.getElementById(id);if(!body)return;var header=body.previousElementSibling;var isOpen=body.classList.contains('open');body.classList.toggle('open',!isOpen);if(header)header.classList.toggle('open',!isOpen);};

document.addEventListener('DOMContentLoaded',function(){
  window.renderQuickMenu();
  if(!document.getElementById('_smDarkCSS')){var st=document.createElement('style');st.id='_smDarkCSS';st.textContent='.dark-toggle-sw{position:relative;display:inline-block;width:44px;height:24px;flex-shrink:0}.dark-toggle-sw input{opacity:0;width:0;height:0}.dark-toggle-sl{position:absolute;cursor:pointer;inset:0;background:#ccc;border-radius:24px;transition:.3s}.dark-toggle-sl:before{content:"";position:absolute;height:18px;width:18px;left:3px;bottom:3px;background:#fff;border-radius:50%;transition:.3s}input:checked+.dark-toggle-sl{background:#5c6afc}input:checked+.dark-toggle-sl:before{transform:translateX(20px)}';document.head.appendChild(st);}
  var m=document.getElementById('sideMenu');if(!m)return;
  var saved=localStorage.getItem('darkMode');
  var isDark=saved==='1'||(saved===null&&window.matchMedia&&window.matchMedia('(prefers-color-scheme: dark)').matches);
  function subAcc(id,label,items){var lis=items.map(function(it){return'<li><a href="'+(it.url||'#')+'" target="_blank">'+it.name+'</a></li>';}).join('');return'<li class="sub-acc-item"><div class="sub-acc-header" onclick="toggleSubAccordion(\''+id+'\')"><span class="sub-arrow">▶</span>'+label+'</div><ul class="sub-acc-body" id="'+id+'">'+lis+'</ul></li>';}
  m.innerHTML=
    '<div class="side-section"><div style="display:flex;align-items:center;justify-content:space-between;padding:13px 16px;"><span style="font-size:13px;font-weight:600;">🌙 ダークモード</span><label class="dark-toggle-sw"><input type="checkbox" id="darkModeToggle"'+(isDark?' checked':'')+' onchange="window.applyDarkMode(this.checked)"><span class="dark-toggle-sl"></span></label></div></div>'+
    '<div class="side-section"><div class="side-section-header" onclick="toggleAccordion(\'linkTools\')">🔧 ツール <span class="arrow">▶</span></div><ul class="accordion-body" id="linkTools">'+
      '<li><a href="https://login.mypurecloud.jp/#/authenticate-adv/org/tci-gp1" target="_blank">Genesys</a></li>'+
      '<li><a href="https://ctssvr501.cloud.contact-link.jp/cts_nhk_net/login/index.php" target="_blank">CRM</a></li>'+
      '<li><a href="https://auth.worksmobile.com/login/login?accessUrl=https%3A%2F%2Fcommon.worksmobile.com%2Fproxy%2Fmy" target="_blank">LINE WORKS</a></li>'+
      '<li><a href="https://tci-dcc-support-summaryai02.spiral-site.com/summary_nhk" target="_blank">対話要約AI</a></li>'+
      '<li><a href="http://tci-ami-web16/Speechvisualizer/" target="_blank">SpeechVisualizer</a></li>'+
    '</ul></div>'+
    '<div class="side-section"><div class="side-section-header" onclick="toggleAccordion(\'linkDocs\')">📄 資料 <span class="arrow">▶</span></div><ul class="accordion-body" id="linkDocs">'+
      subAcc('subDocs_gyoumu','業務資料',[{name:'コンテンツ',url:'#'},{name:'コンテンツ',url:'#'},{name:'コンテンツ',url:'#'}])+
      subAcc('subDocs_oubai','応対品質',[{name:'コンテンツ',url:'#'},{name:'コンテンツ',url:'#'},{name:'コンテンツ',url:'#'}])+
    '</ul></div>'+
    '<div class="side-section"><div class="side-section-header" onclick="toggleAccordion(\'linkSites\')">🌐 関連サイト <span class="arrow">▶</span></div><ul class="accordion-body" id="linkSites">'+
      '<li><a href="https://www.nhk.or.jp/" target="_blank">NHK HP</a></li>'+
      '<li><a href="https://www.nhk.or.jp/nhkone/" target="_blank">NHKONEインフォメーション</a></li>'+
      '<li><a href="https://www.nhk.or.jp/school/" target="_blank">NHK for school</a></li>'+
      '<li><a href="https://www.nhk.or.jp/info/pr/nationwide-nhk/" target="_blank">全国のNHK放送局</a></li>'+
      '<li><a href="https://www.nhk-cs.jp/jushinryo/menjo/window.html" target="_blank">各放送局営業窓口一覧</a></li>'+
      '<li><a href="https://edu-data.jp/" target="_blank">学校コード検索HP</a></li>'+
      '<li><a href="https://www.post.japanpost.jp/zipcode/index.html" target="_blank">郵便局HP</a></li>'+
    '</ul></div>'+
    '<div class="side-section"><div class="side-section-header" onclick="toggleAccordion(\'historyPanel\')">📝 更新履歴 <span class="arrow">▶</span></div>'+
    '<div class="accordion-body" id="historyPanel" style="padding:10px 12px 14px;"><div style="overflow-x:auto;">'+
    '<table style="width:100%;border-collapse:collapse;font-size:11px;min-width:280px;">'+
    '<colgroup><col><col style="width:52px"><col style="width:52px"><col style="width:82px"></colgroup>'+
    '<thead><tr style="background:var(--surface2,#f8f9fa)">'+
    '<th style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:left;font-weight:700;color:var(--text2,#555)">更新内容</th>'+
    '<th style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;font-weight:700;color:var(--text2,#555)">更新者</th>'+
    '<th style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;font-weight:700;color:var(--text2,#555)">承認者</th>'+
    '<th style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;font-weight:700;color:var(--text2,#555)">更新日</th>'+
    '</tr></thead>'+
    '<tbody>'+
    '<tr><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);color:var(--text,#2f3542)">初版作成</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">菅原</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">-</td><td style="padding:6px 8px;border:1px solid var(--border,#e8eaed);text-align:center;color:var(--text,#2f3542)">2026/03/08</td></tr>'+
    '</tbody></table></div></div></div>';

  document.addEventListener('click',function(e){
    if(!e.target.closest('.quick-copy-area')){var qm=document.getElementById('quickMenu');if(qm)qm.classList.remove('open');}
    var btn=document.getElementById('menuBtn');
    if(!m.contains(e.target)&&btn&&e.target!==btn&&!btn.contains(e.target)){m.classList.remove('open');}
  });
});

var ADMIN_PW='admin1234';var _adminUnlocked=false;
window.openAdminWithAuth=function(){if(_adminUnlocked){sessionStorage.setItem('adminAuth','1');window.openNamedTab('admin.html','adminTab');return;}var pw=prompt('管理画面のパスワードを入力してください');if(pw===null)return;if(pw===ADMIN_PW){_adminUnlocked=true;sessionStorage.setItem('adminAuth','1');window.openNamedTab('admin.html','adminTab');}else{alert('パスワードが違います');}};
